import { auth } from '../firebase';

export interface MembershipResponse {
  uid: string;
  tier: 'FREE' | 'VIP' | 'VVIP';
  status: 'ACTIVE' | 'EXPIRED' | 'INACTIVE';
  isVipActive: boolean;
  activatedAt?: string;
  expiresAt?: string;
  remainingSeconds?: number;
  price?: number;
  serverTime: string;
}

export interface PaymentOrderResponse {
  paymentId: string;
  amount: number;
  currency: string;
  tier: string;
  durationDays: number;
  method: string;
  qrisPayload: string;
  validUntil: string;
}

export type ConnectionStatus =
  | 'DISCONNECTED'
  | 'INITIALIZING'
  | 'QR_READY'
  | 'PAIRING_REQUIRED'
  | 'AUTHENTICATING'
  | 'CONNECTED'
  | 'RECONNECTING'
  | 'CONNECTION_EXPIRED'
  | 'ERROR';

export interface WhatsAppStatusPayload {
  uid: string;
  provider: 'gateway' | 'cloud_api';
  status: ConnectionStatus;
  phoneNumber?: string;
  pushName?: string;
  qrCode?: string;
  qrDataUrl?: string;
  pairingCode?: string;
  connectedAt?: string;
  lastHeartbeat?: string;
  lastError?: string | null;
  deviceInfo?: {
    platform: string;
    battery?: number;
    waVersion?: string;
  };
}

export interface WhatsAppStatusResponse {
  status: WhatsAppStatusPayload;
}

class ApiClientService {
  private async getAuthHeaders(): Promise<HeadersInit> {
    const currentUser = auth.currentUser;
    if (!currentUser) {
      throw new Error('Pengguna belum terautentikasi.');
    }
    const token = await currentUser.getIdToken();
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    };
  }

  async getMembershipStatus(): Promise<MembershipResponse> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/membership/status', { headers });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal memuat status membership.');
    }
    return res.json();
  }

  async createPaymentOrder(): Promise<PaymentOrderResponse> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/membership/create-order', {
      method: 'POST',
      headers,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal membuat pesanan pembayaran.');
    }
    return res.json();
  }

  async verifyPayment(paymentId: string): Promise<{ success: boolean; message: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/membership/verify-payment', {
      method: 'POST',
      headers,
      body: JSON.stringify({ paymentId }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal memverifikasi pembayaran.');
    }
    return res.json();
  }

  async getWhatsAppCapabilities(): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/capabilities', { headers });
    return res.json();
  }

  async getWhatsAppStatus(): Promise<WhatsAppStatusResponse> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/status', { headers });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal memuat status WhatsApp.');
    }
    return res.json();
  }

  async connectWhatsApp(provider: 'gateway' | 'cloud_api' = 'gateway'): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/connect', {
      method: 'POST',
      headers,
      body: JSON.stringify({ provider }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal menghubungkan WhatsApp.');
    }
    return res.json();
  }

  async requestPairingCode(phoneNumber: string): Promise<{ success: boolean; pairingCode: string; message: string }> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/request-pairing', {
      method: 'POST',
      headers,
      body: JSON.stringify({ phoneNumber }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || data.error || 'Gagal meminta kode pairing WhatsApp.');
    }
    return data;
  }

  async reconnectWhatsApp(): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/reconnect', {
      method: 'POST',
      headers,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal menyambung ulang sesi WhatsApp.');
    }
    return res.json();
  }

  async disconnectWhatsApp(): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/disconnect', {
      method: 'POST',
      headers,
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal memutuskan sesi WhatsApp.');
    }
    return res.json();
  }

  async getWhatsAppGroups(): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/whatsapp/groups', { headers });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.message || 'Gagal memuat daftar grup WhatsApp.');
    }
    return res.json();
  }

  async sendGroupBroadcast(groupId: string, message: string, mediaUrl?: string): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/broadcast/group', {
      method: 'POST',
      headers,
      body: JSON.stringify({ groupId, message, mediaUrl }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || data.message || 'Gagal mengirim pesan grup.');
    }
    return data;
  }

  async sendContactBroadcast(phoneNumber: string, message: string, mediaUrl?: string): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/broadcast/contact', {
      method: 'POST',
      headers,
      body: JSON.stringify({ phoneNumber, message, mediaUrl }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || data.message || 'Gagal mengirim pesan kontak.');
    }
    return data;
  }

  async sendChannelBroadcast(channelId: string, message: string): Promise<any> {
    const headers = await this.getAuthHeaders();
    const res = await fetch('/api/broadcast/channel', {
      method: 'POST',
      headers,
      body: JSON.stringify({ channelId, message }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || data.message || 'Fitur saluran tidak didukung provider.');
    }
    return data;
  }

  /**
   * Subscribe to real-time WhatsApp updates via Server-Sent Events (SSE)
   */
  async subscribeWhatsAppEvents(
    onUpdate: (state: WhatsAppStatusPayload) => void,
    onError?: (err: any) => void
  ): Promise<() => void> {
    const currentUser = auth.currentUser;
    if (!currentUser) return () => {};

    const token = await currentUser.getIdToken();
    const eventSource = new EventSource(`/api/whatsapp/events?token=${encodeURIComponent(token)}`);

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data && data.status) {
          onUpdate(data);
        }
      } catch (err) {
        console.error('[SSE Client] Parse error:', err);
      }
    };

    eventSource.onerror = (err) => {
      console.warn('[SSE Client] Connection warning:', err);
      if (onError) onError(err);
    };

    return () => {
      eventSource.close();
    };
  }
}

export const ApiClient = new ApiClientService();
