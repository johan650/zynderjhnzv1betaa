import fs from 'fs';
import path from 'path';
import QRCode from 'qrcode';
import pino from 'pino';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  WASocket,
} from '@whiskeysockets/baileys';
import {
  WhatsAppProviderAdapter,
  ProviderCapabilities,
  WhatsAppConnectionState,
  ConnectionStatus,
  SendResult,
  GroupMetadata,
} from './types';

interface InternalUserSession {
  uid: string;
  safeUid: string;
  status: ConnectionStatus;
  sock: WASocket | null;
  phoneNumber?: string;
  pushName?: string;
  qrPayload?: string;
  qrDataUrl?: string;
  pairingCode?: string;
  lastHeartbeat: number;
  connectedAt?: string;
  lastError?: string | null;
  groups: GroupMetadata[];
  qrExpiryTimer?: NodeJS.Timeout | null;
  isInitializing?: boolean;
}

const SESSIONS_BASE_DIR = path.resolve(process.cwd(), 'data', 'sessions');

// Ensure sessions directory exists
if (!fs.existsSync(SESSIONS_BASE_DIR)) {
  fs.mkdirSync(SESSIONS_BASE_DIR, { recursive: true });
}

export class GatewaySessionAdapter implements WhatsAppProviderAdapter {
  id = 'gateway';
  name = 'WhatsApp Multi-Device Gateway (Official Protocol)';

  // Per-user isolated sessions
  private sessions = new Map<string, InternalUserSession>();
  // Real-time event listeners for Server-Sent Events (SSE)
  private listeners = new Map<string, Set<(state: WhatsAppConnectionState) => void>>();

  constructor() {
    // 10-minute inactivity watchdog
    setInterval(() => {
      this.checkInactivityWatchdog();
    }, 60000);
  }

  getCapabilities(): ProviderCapabilities {
    return {
      qrPairing: true,
      groupBroadcast: true,
      channelBroadcast: false,
      contactBroadcast: true,
      mediaMessage: true,
      notes:
        'Koneksi Multi-Device WhatsApp nyata menggunakan protokol resmi WhatsApp Web. Mendukung pemindaian QR Code asli, pairing code 8-karakter langsung dari WhatsApp, pengiriman ke grup di mana nomor menjadi anggota, dan broadcast kontak 1-ke-1. WhatsApp Channels tidak didukung karena enkripsi newsletter Meta belum membuka broadcast terprogram.',
    };
  }

  // Subscribe to real-time connection state updates (used by SSE)
  addListener(userId: string, callback: (state: WhatsAppConnectionState) => void): void {
    if (!this.listeners.has(userId)) {
      this.listeners.set(userId, new Set());
    }
    this.listeners.get(userId)!.add(callback);
  }

  removeListener(userId: string, callback: (state: WhatsAppConnectionState) => void): void {
    const userListeners = this.listeners.get(userId);
    if (userListeners) {
      userListeners.delete(callback);
      if (userListeners.size === 0) {
        this.listeners.delete(userId);
      }
    }
  }

  private notifyListeners(userId: string, state: WhatsAppConnectionState): void {
    const userListeners = this.listeners.get(userId);
    if (userListeners) {
      userListeners.forEach((callback) => {
        try {
          callback(state);
        } catch (err) {
          console.error(`[WhatsApp] Error in listener callback for ${userId}:`, err);
        }
      });
    }
  }

  private getSessionPath(safeUid: string): string {
    return path.join(SESSIONS_BASE_DIR, safeUid);
  }

  private getOrCreateSession(userId: string): InternalUserSession {
    let session = this.sessions.get(userId);
    if (!session) {
      const safeUid = userId.replace(/[^a-zA-Z0-9_-]/g, '_');
      session = {
        uid: userId,
        safeUid,
        status: 'DISCONNECTED',
        sock: null,
        lastHeartbeat: Date.now(),
        groups: [],
      };
      this.sessions.set(userId, session);
    }
    return session;
  }

  /**
   * Watchdog: jika sesi offline / disconnected selama lebih dari 10 menit,
   * ubah status dan hentikan pekerjaan yang memerlukan koneksi.
   */
  private checkInactivityWatchdog(): void {
    const now = Date.now();
    const tenMinutes = 10 * 60 * 1000;

    this.sessions.forEach((session, userId) => {
      if (session.status !== 'CONNECTED' && now - session.lastHeartbeat > tenMinutes) {
        if (session.sock) {
          try {
            session.sock.end(undefined);
          } catch {}
          session.sock = null;
        }
        if (session.status !== 'DISCONNECTED') {
          session.status = 'DISCONNECTED';
          session.qrPayload = undefined;
          session.qrDataUrl = undefined;
          session.pairingCode = undefined;
          this.notifyListeners(userId, this.formatState(session));
        }
      }
    });
  }

  private formatState(session: InternalUserSession): WhatsAppConnectionState {
    return {
      uid: session.uid,
      provider: 'gateway',
      status: session.status,
      phoneNumber: session.phoneNumber,
      pushName: session.pushName,
      qrCode: session.qrPayload,
      qrDataUrl: session.qrDataUrl,
      pairingCode: session.pairingCode,
      connectedAt: session.connectedAt,
      lastHeartbeat: new Date(session.lastHeartbeat).toISOString(),
      lastError: session.lastError,
      deviceInfo: {
        platform: 'WhatsApp Multi-Device Engine (Baileys v6.7)',
        waVersion: '2.3000.x',
      },
    };
  }

  async getStatus(userId: string): Promise<WhatsAppConnectionState> {
    const session = this.getOrCreateSession(userId);
    return this.formatState(session);
  }

  /**
   * Initialize a real WhatsApp connection socket and generate actual authentication QR
   */
  async initSession(userId: string): Promise<WhatsAppConnectionState> {
    const session = this.getOrCreateSession(userId);

    // If already connected and socket is open, return immediately
    if (session.status === 'CONNECTED' && session.sock) {
      session.lastHeartbeat = Date.now();
      return this.formatState(session);
    }

    // If currently initializing, avoid duplicate socket creation
    if (session.isInitializing && session.sock) {
      return this.formatState(session);
    }

    session.isInitializing = true;
    session.status = 'INITIALIZING';
    session.lastError = null;
    session.qrPayload = undefined;
    session.qrDataUrl = undefined;
    session.pairingCode = undefined;
    session.lastHeartbeat = Date.now();
    this.notifyListeners(userId, this.formatState(session));

    // Close any previous stale socket
    if (session.sock) {
      try {
        session.sock.end(undefined);
      } catch {}
      session.sock = null;
    }

    const sessionDir = this.getSessionPath(session.safeUid);
    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }

    try {
      const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
      session.authSaveCreds = saveCreds;

      const silentLogger = pino({ level: 'silent' });

      const sock = makeWASocket({
        auth: state,
        logger: silentLogger,
        printQRInTerminal: false,
        browser: ['ZynderJhnzV1Beta', 'Chrome', '1.0.0'],
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 60000,
        keepAliveIntervalMs: 25000,
        syncFullHistory: false,
      });

      session.sock = sock;

      // Handle credentials update
      sock.ev.on('creds.update', async () => {
        try {
          await saveCreds();
        } catch (err) {
          console.error(`[WhatsApp] Failed to save creds for ${userId}:`, err);
        }
      });

      // Handle connection updates
      sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;
        session.lastHeartbeat = Date.now();

        // 1. REAL QR CODE received directly from WhatsApp authentication server
        if (qr) {
          session.isInitializing = false;
          session.status = 'QR_READY';
          session.qrPayload = qr;

          // Render real, high-resolution scannable QR Code as Data URL
          try {
            session.qrDataUrl = await QRCode.toDataURL(qr, {
              margin: 2,
              width: 320,
              color: {
                dark: '#000000',
                light: '#ffffff',
              },
            });
          } catch (qrErr: any) {
            console.error('[WhatsApp] QR Render Error:', qrErr);
          }

          session.pairingCode = undefined;

          // Set 50-second QR expiry watchdog
          if (session.qrExpiryTimer) clearTimeout(session.qrExpiryTimer);
          session.qrExpiryTimer = setTimeout(() => {
            if (session.status === 'QR_READY') {
              session.status = 'CONNECTION_EXPIRED';
              session.lastError = 'QR Code telah kedaluwarsa. Silakan muat ulang atau buat QR baru.';
              this.notifyListeners(userId, this.formatState(session));
            }
          }, 50000);

          this.notifyListeners(userId, this.formatState(session));
        }

        // 2. Transitioning to AUTHENTICATING
        if (connection === 'connecting') {
          if (session.status === 'QR_READY' || session.status === 'PAIRING_REQUIRED') {
            session.status = 'AUTHENTICATING';
            this.notifyListeners(userId, this.formatState(session));
          }
        }

        // 3. Authenticated: CONNECTION OPEN
        if (connection === 'open') {
          session.isInitializing = false;
          if (session.qrExpiryTimer) clearTimeout(session.qrExpiryTimer);
          session.status = 'CONNECTED';
          session.qrPayload = undefined;
          session.qrDataUrl = undefined;
          session.pairingCode = undefined;
          session.lastError = null;
          session.connectedAt = new Date().toISOString();

          // Extract real phone number and profile name
          if (sock.user) {
            const rawId = sock.user.id || '';
            session.phoneNumber = rawId.split(':')[0].replace(/@.*/, '');
            session.pushName = sock.user.name || (sock.user as any).notify || 'WhatsApp User';
          }

          // Fetch real groups
          try {
            await this.refreshGroups(userId);
          } catch (gErr) {
            console.warn('[WhatsApp] Could not fetch groups immediately:', gErr);
          }

          this.notifyListeners(userId, this.formatState(session));
        }

        // 4. CONNECTION CLOSED / DISCONNECTED
        if (connection === 'close') {
          session.isInitializing = false;
          if (session.qrExpiryTimer) clearTimeout(session.qrExpiryTimer);

          const statusCode = (lastDisconnect?.error as any)?.output?.statusCode;
          const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

          if (statusCode === DisconnectReason.loggedOut) {
            session.status = 'DISCONNECTED';
            session.phoneNumber = undefined;
            session.pushName = undefined;
            session.qrPayload = undefined;
            session.qrDataUrl = undefined;
            session.pairingCode = undefined;
            session.lastError = 'Sesi telah dikeluarkan dari perangkat WhatsApp.';

            // Remove stored session files on logout
            try {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            } catch {}
          } else if (shouldReconnect && session.status === 'CONNECTED') {
            session.status = 'RECONNECTING';
            session.lastError = 'Koneksi terputus sesaat. Menyambung kembali...';
            setTimeout(() => {
              this.reconnect(userId);
            }, 3000);
          } else {
            session.status = session.status === 'QR_READY' ? 'CONNECTION_EXPIRED' : 'DISCONNECTED';
          }

          this.notifyListeners(userId, this.formatState(session));
        }
      });

      return this.formatState(session);
    } catch (err: any) {
      session.isInitializing = false;
      session.status = 'ERROR';
      session.lastError = err.message || 'Gagal memulai koneksi WhatsApp socket.';
      this.notifyListeners(userId, this.formatState(session));
      return this.formatState(session);
    }
  }

  /**
   * Request a real 8-character Pairing Code from WhatsApp's authentication server
   */
  async requestPairingCode(userId: string, phoneNumber: string): Promise<string> {
    const session = this.getOrCreateSession(userId);

    // Ensure session socket is initialized
    if (!session.sock) {
      await this.initSession(userId);
    }

    // Clean phone number: remove non-digits, ensure country code
    let clean = phoneNumber.replace(/\D/g, '');
    if (clean.startsWith('08')) {
      clean = '62' + clean.slice(1);
    } else if (clean.startsWith('8')) {
      clean = '62' + clean;
    }

    if (clean.length < 10) {
      throw new Error('Nomor telepon tidak valid. Gunakan format contoh: 08123456789 atau 628123456789.');
    }

    if (!session.sock) {
      throw new Error('Socket WhatsApp belum siap. Silakan coba kembali.');
    }

    try {
      // Call official Baileys requestPairingCode
      const rawCode = await session.sock.requestPairingCode(clean);
      // Format into readable format e.g. "ABCD-EFGH"
      const formattedCode =
        rawCode.length === 8 ? `${rawCode.slice(0, 4)}-${rawCode.slice(4)}` : rawCode;

      session.pairingCode = formattedCode;
      session.status = 'PAIRING_REQUIRED';
      session.phoneNumber = clean;
      session.qrPayload = undefined;
      session.qrDataUrl = undefined;
      session.lastHeartbeat = Date.now();

      this.notifyListeners(userId, this.formatState(session));
      return formattedCode;
    } catch (err: any) {
      session.status = 'ERROR';
      session.lastError = `Gagal meminta pairing code dari WhatsApp: ${err.message}`;
      this.notifyListeners(userId, this.formatState(session));
      throw new Error(`Gagal meminta pairing code: ${err.message}`);
    }
  }

  async disconnect(userId: string): Promise<{ success: boolean; message: string }> {
    const session = this.getOrCreateSession(userId);

    if (session.qrExpiryTimer) clearTimeout(session.qrExpiryTimer);

    if (session.sock) {
      try {
        session.sock.end(undefined);
      } catch {}
      session.sock = null;
    }

    session.status = 'DISCONNECTED';
    session.phoneNumber = undefined;
    session.pushName = undefined;
    session.qrPayload = undefined;
    session.qrDataUrl = undefined;
    session.pairingCode = undefined;
    session.lastError = null;
    session.groups = [];
    session.lastHeartbeat = Date.now();

    // Clean local session credentials
    const sessionDir = this.getSessionPath(session.safeUid);
    try {
      if (fs.existsSync(sessionDir)) {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      }
    } catch (cleanErr) {
      console.warn('[WhatsApp] Error cleaning session folder:', cleanErr);
    }

    this.notifyListeners(userId, this.formatState(session));

    return {
      success: true,
      message: 'Koneksi WhatsApp berhasil diputus dan sesi kredensial telah dibersihkan secara aman.',
    };
  }

  async reconnect(userId: string): Promise<WhatsAppConnectionState> {
    const session = this.getOrCreateSession(userId);
    if (session.sock) {
      try {
        session.sock.end(undefined);
      } catch {}
      session.sock = null;
    }
    return this.initSession(userId);
  }

  private async refreshGroups(userId: string): Promise<GroupMetadata[]> {
    const session = this.getOrCreateSession(userId);
    if (session.status !== 'CONNECTED' || !session.sock) {
      return [];
    }

    try {
      const rawGroups = await session.sock.groupFetchAllParticipating();
      const groups: GroupMetadata[] = Object.values(rawGroups).map((g) => ({
        id: g.id,
        name: g.subject || 'Grup Komunitas',
        memberCount: g.participants ? g.participants.length : 0,
        isAdmin: Boolean(
          g.participants?.some(
            (p) =>
              p.id.includes(session.phoneNumber || '') &&
              (p.admin === 'admin' || p.admin === 'superadmin')
          )
        ),
        isAnnouncementOnly: Boolean(g.announce),
      }));

      session.groups = groups;
      return groups;
    } catch (err) {
      console.error('[WhatsApp] Error fetching real groups:', err);
      return session.groups;
    }
  }

  async getGroups(userId: string): Promise<GroupMetadata[]> {
    const session = this.getOrCreateSession(userId);
    if (session.status !== 'CONNECTED') {
      return [];
    }
    if (session.groups.length === 0) {
      return this.refreshGroups(userId);
    }
    return session.groups;
  }

  async sendGroupMessage(
    userId: string,
    groupId: string,
    message: string,
    mediaUrl?: string
  ): Promise<SendResult> {
    const session = this.getOrCreateSession(userId);
    if (session.status !== 'CONNECTED' || !session.sock) {
      throw new Error('WhatsApp belum terhubung. Silakan hubungkan WhatsApp terlebih dahulu.');
    }

    const jid = groupId.includes('@g.us') ? groupId : `${groupId}@g.us`;

    try {
      const messageContent: any = { text: message };
      if (mediaUrl) {
        messageContent.image = { url: mediaUrl };
        messageContent.caption = message;
      }

      const sent = await session.sock.sendMessage(jid, messageContent);

      return {
        success: true,
        messageId: sent?.key?.id || `msg-${Date.now()}`,
        status: 'DELIVERED',
        timestamp: new Date().toISOString(),
        provider: this.name,
        recipient: groupId,
      };
    } catch (err: any) {
      throw new Error(`Gagal mengirim pesan ke grup: ${err.message}`);
    }
  }

  async sendContactMessage(
    userId: string,
    phoneNumber: string,
    message: string,
    mediaUrl?: string
  ): Promise<SendResult> {
    const session = this.getOrCreateSession(userId);
    if (session.status !== 'CONNECTED' || !session.sock) {
      throw new Error('WhatsApp belum terhubung. Silakan hubungkan WhatsApp terlebih dahulu.');
    }

    let clean = phoneNumber.replace(/\D/g, '');
    if (clean.startsWith('08')) {
      clean = '62' + clean.slice(1);
    } else if (clean.startsWith('8')) {
      clean = '62' + clean;
    }

    const jid = `${clean}@s.whatsapp.net`;

    try {
      const messageContent: any = { text: message };
      if (mediaUrl) {
        messageContent.image = { url: mediaUrl };
        messageContent.caption = message;
      }

      const sent = await session.sock.sendMessage(jid, messageContent);

      return {
        success: true,
        messageId: sent?.key?.id || `msg-${Date.now()}`,
        status: 'DELIVERED',
        timestamp: new Date().toISOString(),
        provider: this.name,
        recipient: phoneNumber,
      };
    } catch (err: any) {
      throw new Error(`Gagal mengirim pesan ke kontak: ${err.message}`);
    }
  }

  async sendChannelMessage(
    userId: string,
    channelId: string,
    message: string
  ): Promise<SendResult> {
    return {
      success: false,
      status: 'REJECTED',
      timestamp: new Date().toISOString(),
      provider: this.name,
      recipient: channelId,
      error:
        'WhatsApp Channels (Saluran) berstatus BELUM TERSEDIA. Protokol WhatsApp multi-device saat ini belum membuka akses pengiriman broadcast terprogram ke Channels newsletter Meta.',
    };
  }
}
