/**
 * WhatsApp Integration Types & Provider Adapter Interfaces
 * Designed for modular swap between Meta Cloud API and Gateway Sessions.
 */

export type ConnectionStatus =
  | 'DISCONNECTED'
  | 'INITIALIZING'
  | 'QR_READY'
  | 'PAIRING_REQUIRED'
  | 'AUTHENTICATING'
  | 'CONNECTED'
  | 'RECONNECTING'
  | 'CONNECTION_EXPIRED'
  | 'ERROR';

export interface ProviderCapabilities {
  qrPairing: boolean;
  groupBroadcast: boolean;
  channelBroadcast: boolean;
  contactBroadcast: boolean;
  mediaMessage: boolean;
  notes: string;
}

export interface WhatsAppConnectionState {
  uid: string;
  provider: 'gateway' | 'cloud_api';
  status: ConnectionStatus;
  phoneNumber?: string;
  pushName?: string;
  qrCode?: string;
  qrDataUrl?: string;
  pairingCode?: string;
  connectedAt?: string;
  lastHeartbeat?: string;
  lastError?: string | null;
  deviceInfo?: {
    platform: string;
    battery?: number;
    waVersion?: string;
  };
}

export interface SendResult {
  success: boolean;
  messageId?: string;
  status: 'ACCEPTED' | 'DELIVERED' | 'FAILED' | 'REJECTED';
  timestamp: string;
  provider: string;
  recipient: string;
  error?: string;
}

export interface GroupMetadata {
  id: string;
  name: string;
  memberCount: number;
  isAdmin: boolean;
  isAnnouncementOnly: boolean;
}

export interface WhatsAppProviderAdapter {
  id: string;
  name: string;
  getCapabilities(): ProviderCapabilities;
  initSession(userId: string): Promise<WhatsAppConnectionState>;
  disconnect(userId: string): Promise<{ success: boolean; message: string }>;
  getStatus(userId: string): Promise<WhatsAppConnectionState>;
  sendContactMessage(
    userId: string,
    phoneNumber: string,
    message: string,
    mediaUrl?: string
  ): Promise<SendResult>;
  sendGroupMessage(
    userId: string,
    groupId: string,
    message: string,
    mediaUrl?: string
  ): Promise<SendResult>;
  sendChannelMessage(
    userId: string,
    channelId: string,
    message: string
  ): Promise<SendResult>;
  getGroups(userId: string): Promise<GroupMetadata[]>;
  requestPairingCode?(userId: string, phoneNumber: string): Promise<string>;
}
