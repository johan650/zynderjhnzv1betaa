/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { DashboardPreview } from './components/DashboardPreview';
import { AboutSection } from './components/AboutSection';
import { KeunggulanSection } from './components/KeunggulanSection';
import { FiturUtamaSection } from './components/FiturUtamaSection';
import { VipSection } from './components/VipSection';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';
import { LoginModal } from './components/auth/LoginModal';
import { InfoModals } from './components/public/InfoModals';
import { ProtectedDashboard } from './components/dashboard/ProtectedDashboard';

function MainAppContent() {
  const { user, loading } = useAuth();
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [infoModalType, setInfoModalType] = useState<'terms' | 'privacy' | 'faq' | 'contact' | null>(null);
  const [viewState, setViewState] = useState<'landing' | 'dashboard'>('landing');

  // If user just logged in and wants dashboard, switch to dashboard
  const handleOpenLogin = () => {
    if (user) {
      setViewState('dashboard');
    } else {
      setIsLoginModalOpen(true);
    }
  };

  const handleGoToDashboard = () => {
    if (user) {
      setViewState('dashboard');
    } else {
      setIsLoginModalOpen(true);
    }
  };

  // If user is logged in and on dashboard view, render Protected Dashboard
  if (user && viewState === 'dashboard') {
    return (
      <ProtectedDashboard
        onReturnToLanding={() => setViewState('landing')}
      />
    );
  }

  // Otherwise, render Public Landing Page
  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Navigation */}
      <Navbar
        onOpenLogin={handleOpenLogin}
        onOpenFaq={() => setInfoModalType('faq')}
        onOpenContact={() => setInfoModalType('contact')}
        onGoToDashboard={handleGoToDashboard}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <HeroSection onOpenModal={handleOpenLogin} />

        {/* Live Interactive Dashboard Preview Showcase */}
        <DashboardPreview />

        {/* About Section */}
        <AboutSection />

        {/* Keunggulan Platform */}
        <KeunggulanSection />

        {/* Fitur Utama */}
        <FiturUtamaSection />

        {/* VIP Membership Tiers */}
        <VipSection onOpenModal={handleOpenLogin} />

        {/* Call to Action */}
        <CtaSection onOpenModal={handleOpenLogin} />
      </main>

      {/* Quiet Footer with Public Policy Modals */}
      <Footer
        onOpenTerms={() => setInfoModalType('terms')}
        onOpenPrivacy={() => setInfoModalType('privacy')}
        onOpenFaq={() => setInfoModalType('faq')}
        onOpenContact={() => setInfoModalType('contact')}
      />

      {/* Google Authentication Modal */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onOpenPrivacy={() => setInfoModalType('privacy')}
        onOpenTerms={() => setInfoModalType('terms')}
      />

      {/* Public Pages: Terms, Privacy, FAQ, Contact Modals */}
      <InfoModals
        type={infoModalType}
        onClose={() => setInfoModalType(null)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
