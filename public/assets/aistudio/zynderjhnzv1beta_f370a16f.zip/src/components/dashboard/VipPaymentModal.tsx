import React, { useState } from 'react';
import { X, Crown, CheckCircle2, QrCode, ShieldCheck, Loader2, Copy, Check } from 'lucide-react';
import { ApiClient } from '../../services/apiClient';

interface VipPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const VipPaymentModal: React.FC<VipPaymentModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [loading, setLoading] = useState(false);
  const [paymentData, setPaymentData] = useState<{
    paymentId: string;
    amount: number;
    qrisPayload: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load payment details when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setLoading(true);
      setErrorMessage(null);
      ApiClient.createPaymentOrder()
        .then((data) => {
          setPaymentData(data);
        })
        .catch((err) => {
          setErrorMessage(err.message || 'Gagal memuat instruksi pembayaran.');
        })
        .finally(() => setLoading(false));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopyQris = () => {
    if (paymentData?.qrisPayload) {
      navigator.clipboard.writeText(paymentData.qrisPayload);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleConfirmPayment = async () => {
    if (!paymentData) return;
    setIsVerifying(true);
    setErrorMessage(null);

    try {
      await ApiClient.verifyPayment(paymentData.paymentId);
      onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Verifikasi pembayaran gagal.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-md rounded-2xl bg-[#0c101d] border border-cyan-500/30 p-6 sm:p-7 shadow-2xl shadow-cyan-950/50 text-slate-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Tutup jendela pembayaran"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
          <Crown className="w-4 h-4" />
          <span>Aktivasi Membership VIP</span>
        </div>

        <h3 className="text-xl font-extrabold text-white">
          Upgrade Akses VIP ZynderJhnzV1Beta
        </h3>
        <p className="mt-1 text-xs text-slate-400">
          Buka akses penuh ke WhatsApp Connection, Group Broadcast, dan Contact Pushkontak.
        </p>

        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center text-xs text-slate-400 space-y-3">
            <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
            <span>Menyiapkan tagihan pembayaran QRIS...</span>
          </div>
        ) : errorMessage ? (
          <div className="my-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {errorMessage}
          </div>
        ) : paymentData ? (
          <div className="mt-5 space-y-4">
            {/* Price Banner */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-400">Total Tagihan (30 Hari):</span>
                <div className="text-xl font-extrabold font-mono text-cyan-400 mt-0.5">
                  Rp 10.000
                </div>
              </div>
              <span className="px-2.5 py-1 text-xs font-semibold rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Otomatis Aktif
              </span>
            </div>

            {/* Simulated Real QRIS Code */}
            <div className="p-4 bg-white rounded-2xl flex flex-col items-center text-center shadow-lg">
              <div className="w-48 h-48 bg-slate-950 rounded-xl p-2 flex flex-col items-center justify-center">
                <QrCode className="w-40 h-40 text-cyan-400" />
              </div>
              <div className="text-[11px] font-bold text-slate-800 mt-2">
                QRIS NASIONAL — ZYNDERJHNZV1BETA
              </div>
              <div className="text-[10px] text-slate-500">
                Dapat dipindai melalui BCA, Mandiri, BRI, BNI, GoPay, OVO, Dana
              </div>
            </div>

            {/* Invoice Reference */}
            <div className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
              <span className="text-slate-400 font-mono text-[11px]">No. Pesanan: {paymentData.paymentId}</span>
              <button
                onClick={handleCopyQris}
                className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Tersalin' : 'Salin String QRIS'}</span>
              </button>
            </div>

            {/* Confirm Payment Button */}
            <button
              onClick={handleConfirmPayment}
              disabled={isVerifying}
              className="w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md shadow-cyan-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
            >
              {isVerifying ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Memverifikasi Pembayaran...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Konfirmasi Pembayaran (Rp10.000)</span>
                </>
              )}
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Verifikasi waktu server instan 30 hari penuh</span>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
