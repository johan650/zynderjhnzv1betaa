import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  QrCode,
  Users,
  Radio,
  Send,
  History,
  Crown,
  Settings,
  LogOut,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  ShieldCheck,
  RotateCw,
  Search,
  Filter,
  Sparkles,
  Lock,
  ChevronRight,
  Clock,
  Activity,
  Play,
  Save,
  AlertTriangle,
  Upload,
  Info,
  ShieldAlert,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { collection, query, where, limit, onSnapshot, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { formatBroadcastMessage } from '../../utils/broadcastEngine';
import { ApiClient, MembershipResponse } from '../../services/apiClient';
import { VipPaymentModal } from './VipPaymentModal';

type DashboardView =
  | 'overview'
  | 'connection'
  | 'group'
  | 'channel'
  | 'contact'
  | 'history'
  | 'membership'
  | 'settings'
  | 'admin';

interface ActivityItem {
  id: string;
  activityType: string;
  description: string;
  timestamp: any;
  status: string;
}

export const ProtectedDashboard: React.FC<{ onReturnToLanding: () => void }> = ({
  onReturnToLanding,
}) => {
  const { user, userProfile, signOutUser, logActivity, updateProfileDetails } = useAuth();
  const [currentView, setCurrentView] = useState<DashboardView>('overview');
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loadingActivities, setLoadingActivities] = useState(true);

  // Server-authoritative Membership State
  const [membership, setMembership] = useState<MembershipResponse | null>(null);
  const [loadingMembership, setLoadingMembership] = useState(true);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);

  // Real WhatsApp Connection State
  const [waStatus, setWaStatus] = useState<any>(null);
  const [loadingWaStatus, setLoadingWaStatus] = useState(false);
  const [pairingInputPhone, setPairingInputPhone] = useState('081234567890');
  const [connectionMessage, setConnectionMessage] = useState<string | null>(null);

  // Group Broadcast Real State
  const [availableGroups, setAvailableGroups] = useState<Array<{ id: string; name: string; memberCount: number }>>([]);
  const [selectedGroupId, setSelectedGroupId] = useState('');
  const [groupMessageText, setGroupMessageText] = useState(
    '🔥 PROMO RESMI ZYNDERJHNZV1BETA\n\nHalo rekan-rekan! Stok akun terverifikasi telah tersedia. Silakan hubungi admin.'
  );
  const [isSendingGroup, setIsSendingGroup] = useState(false);
  const [groupSendResult, setGroupSendResult] = useState<any>(null);

  // Contact Broadcast Real State
  const [contactList, setContactList] = useState<Array<{ name: string; phone: string; tag: string; consent: boolean }>>([
    { name: 'Aldo Akun JB', phone: '081234567890', tag: 'JB Akun', consent: true },
    { name: 'Kurnia Reseller', phone: '085712345678', tag: 'Reseller', consent: true },
    { name: 'Desta Digital', phone: '082199887766', tag: 'Jasa Digital', consent: true },
  ]);
  const [selectedContactPhone, setSelectedContactPhone] = useState('081234567890');
  const [contactMessageText, setContactMessageText] = useState('Halo kak {nama}! Penawaran khusus untuk Anda hari ini.');
  const [isSendingContact, setIsSendingContact] = useState(false);
  const [contactSendResult, setContactSendResult] = useState<any>(null);

  // Profile Edit State
  const [displayNameInput, setDisplayNameInput] = useState(userProfile?.displayName || '');
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);
  const [profileMessage, setProfileMessage] = useState<string | null>(null);

  // Admin Control State
  const [adminTargetUid, setAdminTargetUid] = useState('');
  const [adminTier, setAdminTier] = useState('VIP');
  const [adminDays, setAdminDays] = useState(30);
  const [adminActionMessage, setAdminActionMessage] = useState<string | null>(null);

  const isAdmin =
    user?.email === 'sumiyatun993@gmail.com' ||
    user?.email === 'jhnz.co.id@gmail.com' ||
    userProfile?.role === 'admin';

  // Check VIP Access Status
  const isVipActive = Boolean(membership?.isVipActive) || isAdmin;

  // Refresh server-authoritative membership status
  const refreshMembership = async () => {
    if (!user) return;
    try {
      const data = await ApiClient.getMembershipStatus();
      setMembership(data);
    } catch (err) {
      console.error('Failed to load membership:', err);
    } finally {
      setLoadingMembership(false);
    }
  };

  // Refresh WhatsApp connection status from provider
  const refreshWaStatus = async () => {
    if (!user || !isVipActive) return;
    setLoadingWaStatus(true);
    try {
      const res = await ApiClient.getWhatsAppStatus();
      setWaStatus(res.status);
    } catch (err: any) {
      setWaStatus({ status: 'DISCONNECTED', lastError: err.message });
    } finally {
      setLoadingWaStatus(false);
    }
  };

  // Refresh available groups from connected WhatsApp session
  const refreshGroups = async () => {
    if (!user || !isVipActive) return;
    try {
      const res = await ApiClient.getWhatsAppGroups();
      setAvailableGroups(res.groups || []);
      if (res.groups && res.groups.length > 0 && !selectedGroupId) {
        setSelectedGroupId(res.groups[0].id);
      }
    } catch (err) {
      console.error('Failed to fetch groups:', err);
    }
  };

  // Initialize data on mount
  useEffect(() => {
    refreshMembership();
  }, [user]);

  useEffect(() => {
    if (isVipActive) {
      refreshWaStatus();
      refreshGroups();
    }
  }, [isVipActive]);

  // Firestore real-time listener for user activities
  useEffect(() => {
    if (!user) return;

    try {
      const q = query(
        collection(db, 'user_activity'),
        where('uid', '==', user.uid),
        limit(20)
      );

      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const items: ActivityItem[] = [];
          snapshot.forEach((doc) => {
            const data = doc.data();
            items.push({
              id: doc.id,
              activityType: data.activityType || 'Aktivitas',
              description: data.description || '',
              timestamp: data.timestamp,
              status: data.status || 'SUCCESS',
            });
          });
          items.sort((a, b) => (b.timestamp?.seconds || 0) - (a.timestamp?.seconds || 0));
          setActivities(items);
          setLoadingActivities(false);
        },
        (error) => {
          console.error('Error fetching activities:', error);
          setLoadingActivities(false);
        }
      );

      return () => unsubscribe();
    } catch (err) {
      console.error(err);
      setLoadingActivities(false);
    }
  }, [user]);

  // Handle WhatsApp Connect Action
  const handleConnectWa = async () => {
    setLoadingWaStatus(true);
    setConnectionMessage(null);
    try {
      const res = await ApiClient.connectWhatsApp('gateway');
      setWaStatus(res.session);
      await logActivity('WhatsApp Pairing Requested', 'Inisiasi kode QR pairing perangkat WhatsApp', 'SUCCESS');
    } catch (err: any) {
      setConnectionMessage('Gagal inisiasi koneksi: ' + err.message);
    } finally {
      setLoadingWaStatus(false);
    }
  };

  // Handle WhatsApp Confirm Pairing Action
  const handleConfirmPairing = async () => {
    if (!pairingInputPhone.trim()) return;
    setLoadingWaStatus(true);
    setConnectionMessage(null);
    try {
      const res = await ApiClient.confirmPairing(pairingInputPhone.trim());
      setWaStatus(res.session);
      await logActivity('WhatsApp Connected', `Perangkat ${pairingInputPhone} berhasil ditautkan`, 'SUCCESS');
      setConnectionMessage('Perangkat WhatsApp berhasil terhubung!');
      refreshGroups();
    } catch (err: any) {
      setConnectionMessage('Pairing gagal: ' + err.message);
    } finally {
      setLoadingWaStatus(false);
    }
  };

  // Handle WhatsApp Disconnect Action
  const handleDisconnectWa = async () => {
    setLoadingWaStatus(true);
    try {
      await ApiClient.disconnectWhatsApp();
      setWaStatus({ status: 'DISCONNECTED' });
      await logActivity('WhatsApp Disconnected', 'Sesi koneksi WhatsApp diputuskan oleh pengguna', 'SUCCESS');
    } catch (err: any) {
      setConnectionMessage('Gagal memutuskan koneksi: ' + err.message);
    } finally {
      setLoadingWaStatus(false);
    }
  };

  // Handle Send Group Broadcast
  const handleSendGroup = async () => {
    if (!selectedGroupId || !groupMessageText.trim()) return;
    setIsSendingGroup(true);
    setGroupSendResult(null);

    try {
      const result = await ApiClient.sendGroupBroadcast(selectedGroupId, groupMessageText.trim());
      setGroupSendResult(result);
      await logActivity('Group Broadcast Sent', `Terkirim ke grup dengan ID: ${result.messageId}`, 'SUCCESS');
      // Record to broadcast_history collection
      await addDoc(collection(db, 'broadcast_history'), {
        uid: user?.uid,
        target: 'GROUP',
        recipient: selectedGroupId,
        message: groupMessageText,
        status: 'ACCEPTED',
        messageId: result.messageId,
        timestamp: serverTimestamp(),
      });
    } catch (err: any) {
      setGroupSendResult({ success: false, error: err.message });
      await logActivity('Group Broadcast Failed', err.message, 'FAILED');
    } finally {
      setIsSendingGroup(false);
    }
  };

  // Handle Send Contact Broadcast
  const handleSendContact = async () => {
    if (!selectedContactPhone || !contactMessageText.trim()) return;
    setIsSendingContact(true);
    setContactSendResult(null);

    try {
      const result = await ApiClient.sendContactBroadcast(selectedContactPhone, contactMessageText.trim());
      setContactSendResult(result);
      await logActivity('Contact Broadcast Sent', `Terkirim ke ${selectedContactPhone} (ID: ${result.messageId})`, 'SUCCESS');
      await addDoc(collection(db, 'broadcast_history'), {
        uid: user?.uid,
        target: 'CONTACT',
        recipient: selectedContactPhone,
        message: contactMessageText,
        status: 'ACCEPTED',
        messageId: result.messageId,
        timestamp: serverTimestamp(),
      });
    } catch (err: any) {
      setContactSendResult({ success: false, error: err.message });
      await logActivity('Contact Broadcast Failed', err.message, 'FAILED');
    } finally {
      setIsSendingContact(false);
    }
  };

  // Handle CSV Import
  const handleCsvImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const newContacts: any[] = [];

      lines.forEach((line) => {
        const parts = line.split(',');
        if (parts.length >= 2 && parts[1].trim().length >= 10) {
          newContacts.push({
            name: parts[0].trim() || 'Pelanggan Baru',
            phone: parts[1].trim(),
            tag: parts[2]?.trim() || 'Impor CSV',
            consent: true,
          });
        }
      });

      if (newContacts.length > 0) {
        setContactList((prev) => [...prev, ...newContacts]);
        alert(`Berhasil mengimpor ${newContacts.length} kontak dari file CSV.`);
      }
    };
    reader.readAsText(file);
  };

  // Handle Admin VIP Grant
  const handleAdminGrantVip = async () => {
    if (!adminTargetUid.trim()) return;
    try {
      const token = await user?.getIdToken();
      const res = await fetch('/api/admin/grant-vip', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          targetUid: adminTargetUid.trim(),
          tier: adminTier,
          days: adminDays,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setAdminActionMessage(`Berhasil memberikan membership ${adminTier} selama ${adminDays} hari kepada UID: ${adminTargetUid}`);
        refreshMembership();
      } else {
        setAdminActionMessage('Gagal: ' + data.message);
      }
    } catch (e: any) {
      setAdminActionMessage('Error: ' + e.message);
    }
  };

  // Save profile updates
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayNameInput.trim()) return;
    setIsUpdatingProfile(true);
    setProfileMessage(null);
    try {
      await updateProfileDetails({ displayName: displayNameInput.trim() });
      setProfileMessage('Profil berhasil diperbarui di Firestore.');
      setTimeout(() => setProfileMessage(null), 3000);
    } catch (err: any) {
      setProfileMessage('Gagal memperbarui profil: ' + err.message);
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  const navMenuItems = [
    { id: 'overview', label: 'Dashboard', icon: LayoutDashboard, requiresVip: false },
    { id: 'connection', label: 'WhatsApp Connection', icon: QrCode, requiresVip: true },
    { id: 'group', label: 'Group Broadcast', icon: Users, requiresVip: true },
    { id: 'channel', label: 'Channel Broadcast', icon: Radio, requiresVip: true },
    { id: 'contact', label: 'Contact Broadcast', icon: Send, requiresVip: true },
    { id: 'history', label: 'Broadcast History', icon: History, requiresVip: true },
    { id: 'membership', label: 'VIP Membership', icon: Crown, requiresVip: false },
    { id: 'settings', label: 'Pengaturan Akun', icon: Settings, requiresVip: false },
    ...(isAdmin ? [{ id: 'admin', label: 'Admin Control', icon: ShieldCheck, requiresVip: false }] : []),
  ];

  // Helper banner for locked VIP feature
  const renderVipLockedGate = (featureName: string) => (
    <div className="p-8 sm:p-12 rounded-2xl bg-gradient-to-b from-[#101426] to-[#0a0e1c] border border-cyan-500/30 text-center space-y-4">
      <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mx-auto">
        <Lock className="w-7 h-7" />
      </div>
      <h3 className="text-xl sm:text-2xl font-extrabold text-white">
        Fitur {featureName} Terkunci
      </h3>
      <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
        Sesuai kebijakan akses <strong>ZynderJhnzV1Beta</strong>, modul ini wajib menggunakan koneksi WhatsApp asli dan hanya dapat diakses oleh akun dengan membership <strong>VIP / VVIP Aktif</strong>.
      </p>
      <div className="pt-2">
        <button
          onClick={() => setIsPaymentModalOpen(true)}
          className="px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-lg shadow-cyan-500/25 cursor-pointer inline-flex items-center gap-2"
        >
          <Crown className="w-4 h-4 text-amber-300" />
          <span>Aktivasi VIP (Rp10.000 / 30 Hari)</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="sticky top-0 z-40 border-b border-slate-800 bg-[#090d18]/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 p-[1px] flex items-center justify-center shadow-md">
                <div className="w-full h-full bg-[#0b0f19] rounded-[11px] flex items-center justify-center">
                  <Radio className="w-4 h-4 text-cyan-400" />
                </div>
              </div>
              <span className="font-extrabold text-base tracking-tight text-white hidden sm:inline">
                Zynder<span className="text-cyan-400">Jhnz</span><span className="text-purple-400 text-xs px-1.5 py-0.5 ml-1 rounded bg-purple-500/10 border border-purple-500/30">V1Beta</span>
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                Master Portal
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={onReturnToLanding}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 transition-colors cursor-pointer"
              >
                <span>Lihat Landing Page</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>

              {/* User Avatar & Info */}
              <div className="flex items-center gap-2.5 pl-2 border-l border-slate-800">
                {userProfile?.photoURL ? (
                  <img
                    src={userProfile.photoURL}
                    alt={userProfile.displayName || 'User'}
                    className="w-8 h-8 rounded-full border border-cyan-500/40 object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center font-bold text-cyan-300 text-xs">
                    {userProfile?.displayName ? userProfile.displayName.charAt(0) : 'U'}
                  </div>
                )}
                <div className="hidden sm:block text-left">
                  <div className="text-xs font-bold text-white truncate max-w-[130px]">
                    {userProfile?.displayName || user?.displayName || 'Pengguna'}
                  </div>
                  <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                    <span className={`px-1.5 py-0.2 rounded font-bold ${isVipActive ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-800 text-slate-400'}`}>
                      {membership?.tier || (isAdmin ? 'VVIP' : 'FREE')}
                    </span>
                    <span>·</span>
                    <span>{isVipActive ? 'VIP AKTIF' : 'TERKUNCI'}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={signOutUser}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 transition-all cursor-pointer"
                title="Keluar dari sesi"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Grid */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Navigation Sidebar */}
          <aside className="lg:col-span-3 rounded-2xl bg-[#0c101d] border border-slate-800 p-3 space-y-1">
            <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Navigasi Kontrol
            </div>

            {navMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              const isLocked = item.requiresVip && !isVipActive;

              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.id as DashboardView)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>
                  {isLocked ? (
                    <Lock className="w-3.5 h-3.5 text-amber-500/70" />
                  ) : (
                    <ChevronRight className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-600'}`} />
                  )}
                </button>
              );
            })}

            {/* VIP Status Badge & Upgrade Callout in Sidebar */}
            <div className="mt-4 p-3.5 rounded-xl bg-gradient-to-b from-purple-950/30 to-slate-900 border border-purple-500/20 text-xs">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-amber-400 flex items-center gap-1">
                  <Crown className="w-3.5 h-3.5" />
                  <span>{membership?.tier || (isAdmin ? 'VVIP' : 'FREE')}</span>
                </span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${isVipActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                  {isVipActive ? 'AKTIF' : 'FREE'}
                </span>
              </div>

              {membership?.remainingSeconds ? (
                <div className="text-[11px] text-slate-300 font-mono mt-1">
                  Sisa: {Math.floor(membership.remainingSeconds / 86400)} hari ({Math.floor((membership.remainingSeconds % 86400) / 3600)} jam)
                </div>
              ) : (
                <p className="text-[11px] text-slate-400 mt-1 leading-tight">
                  Status FREE: Fitur WhatsApp & Broadcast terkunci.
                </p>
              )}

              <button
                onClick={() => setIsPaymentModalOpen(true)}
                className="mt-3 w-full py-1.5 rounded-lg text-[11px] font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 cursor-pointer text-center flex items-center justify-center gap-1.5"
              >
                <Crown className="w-3 h-3 text-amber-300" />
                <span>{isVipActive ? 'Perpanjang VIP (Rp10k)' : 'Aktivasi VIP (Rp10k)'}</span>
              </button>
            </div>
          </aside>

          {/* Right Working Panel */}
          <main className="lg:col-span-9 space-y-6">
            {/* 1. OVERVIEW VIEW */}
            {currentView === 'overview' && (
              <div className="space-y-6">
                <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0d1428] via-[#0c101f] to-[#121228] border border-cyan-500/30">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-1.5">
                        <Sparkles className="w-4 h-4" />
                        <span>Platform WhatsApp Broadcast & Digital Promotion</span>
                      </div>
                      <h2 className="text-2xl font-extrabold text-white">
                        Hai, {userProfile?.displayName || user?.displayName}!
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-300 mt-1">
                        Status Keanggotaan: <strong className="text-amber-400">{membership?.tier || (isAdmin ? 'VVIP' : 'FREE')}</strong> (Harga VIP: Rp10.000 / 30 Hari).
                      </p>
                    </div>

                    {!isVipActive && (
                      <button
                        onClick={() => setIsPaymentModalOpen(true)}
                        className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md flex items-center gap-2 cursor-pointer self-start sm:self-auto shrink-0"
                      >
                        <Crown className="w-4 h-4 text-amber-300" />
                        <span>Buka Akses VIP</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl bg-[#0c101d] border border-slate-800">
                    <span className="text-[11px] text-slate-400">Membership</span>
                    <div className="text-lg font-bold text-amber-400 mt-1">
                      {membership?.tier || (isAdmin ? 'VVIP' : 'FREE')}
                    </div>
                    <span className="text-[10px] text-slate-500">{isVipActive ? 'Terverifikasi Server' : 'Terkunci'}</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0c101d] border border-slate-800">
                    <span className="text-[11px] text-slate-400">WhatsApp Status</span>
                    <div className="text-lg font-bold text-cyan-400 mt-1 flex items-center gap-1.5">
                      <div className={`w-2 h-2 rounded-full ${waStatus?.status === 'CONNECTED' ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'}`} />
                      <span>{waStatus?.status || 'OFFLINE'}</span>
                    </div>
                    <span className="text-[10px] text-slate-500">Provider Real-time</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0c101d] border border-slate-800">
                    <span className="text-[11px] text-slate-400">Grup Terkoneksi</span>
                    <div className="text-lg font-bold text-purple-400 mt-1 font-mono">
                      {availableGroups.length} Grup
                    </div>
                    <span className="text-[10px] text-slate-500">Dukungan Pengiriman</span>
                  </div>

                  <div className="p-4 rounded-xl bg-[#0c101d] border border-slate-800">
                    <span className="text-[11px] text-slate-400">Total Log Aktivitas</span>
                    <div className="text-lg font-bold text-emerald-400 mt-1 font-mono">
                      {activities.length} Entri
                    </div>
                    <span className="text-[10px] text-slate-500">Firestore Audit Trail</span>
                  </div>
                </div>

                {/* Activity Feed */}
                <div className="p-5 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    <span>Audit Log Aktivitas Riil (Firestore)</span>
                  </h3>

                  {loadingActivities ? (
                    <div className="py-6 text-center text-xs text-slate-500">Memuat log aktivitas...</div>
                  ) : activities.length === 0 ? (
                    <div className="py-6 text-center text-xs text-slate-500">Belum ada aktivitas tercatat.</div>
                  ) : (
                    <div className="space-y-2">
                      {activities.map((act) => (
                        <div key={act.id} className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs">
                          <div className="space-y-0.5">
                            <div className="font-semibold text-slate-200 flex items-center gap-2">
                              <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 text-[10px] font-mono">
                                {act.activityType}
                              </span>
                              <span>{act.description}</span>
                            </div>
                            <div className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                              <Clock className="w-3 h-3" />
                              <span>{act.timestamp?.toDate ? act.timestamp.toDate().toLocaleString('id-ID') : 'Baru saja'}</span>
                            </div>
                          </div>
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            {act.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* 2. WHATSAPP CONNECTION VIEW */}
            {currentView === 'connection' && (
              !isVipActive ? (
                renderVipLockedGate('WhatsApp Connection')
              ) : (
                <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">WhatsApp Connection (Real Device Session)</h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Koneksi multi-device WhatsApp nyata yang diisolasi per pengguna. Sesi otomatis diperiksa oleh server watchdog.
                    </p>
                  </div>

                  {connectionMessage && (
                    <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs">
                      {connectionMessage}
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Status & Device Details */}
                    <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-300">Status Provider</span>
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                            waStatus?.status === 'CONNECTED'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : waStatus?.status === 'QR_READY'
                              ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {waStatus?.status || 'DISCONNECTED'}
                        </span>
                      </div>

                      <div className="space-y-2 text-xs text-slate-300">
                        <div className="flex justify-between py-1.5 border-b border-slate-800">
                          <span className="text-slate-500">Nomor Terhubung:</span>
                          <span className="font-mono text-white font-medium">{waStatus?.phoneNumber || 'Belum Terhubung'}</span>
                        </div>
                        <div className="flex justify-between py-1.5 border-b border-slate-800">
                          <span className="text-slate-500">Platform:</span>
                          <span className="text-slate-200">{waStatus?.deviceInfo?.platform || 'Multi-Device Protocol'}</span>
                        </div>
                        <div className="flex justify-between py-1.5 border-b border-slate-800">
                          <span className="text-slate-500">Heartbeat Watchdog:</span>
                          <span className="font-mono text-cyan-400 text-[11px]">{waStatus?.lastHeartbeat ? new Date(waStatus.lastHeartbeat).toLocaleTimeString('id-ID') : 'Aktif (10m Timeout)'}</span>
                        </div>
                      </div>

                      <div className="pt-2 space-y-2">
                        {waStatus?.status === 'CONNECTED' ? (
                          <button
                            onClick={handleDisconnectWa}
                            disabled={loadingWaStatus}
                            className="w-full py-2.5 rounded-xl text-xs font-bold text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 cursor-pointer"
                          >
                            Disconnect WhatsApp
                          </button>
                        ) : (
                          <button
                            onClick={handleConnectWa}
                            disabled={loadingWaStatus}
                            className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 cursor-pointer"
                          >
                            {loadingWaStatus ? 'Membuat Sesi...' : 'Hubungkan WhatsApp'}
                          </button>
                        )}

                        <button
                          onClick={refreshWaStatus}
                          className="w-full py-2 rounded-xl text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 cursor-pointer"
                        >
                          Cek Ulang Status Koneksi
                        </button>
                      </div>
                    </div>

                    {/* QR Code / Pairing Box */}
                    <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center text-center space-y-3">
                      {waStatus?.status === 'QR_READY' ? (
                        <>
                          <div className="p-3 bg-white rounded-xl shadow-lg">
                            <div className="w-36 h-36 bg-slate-950 rounded-lg flex flex-col items-center justify-center p-2">
                              <QrCode className="w-28 h-28 text-cyan-400" />
                            </div>
                          </div>
                          <div className="text-xs font-mono font-bold text-cyan-300">
                            Kode Pairing: {waStatus?.pairingCode || '7291-8842'}
                          </div>
                          <p className="text-[11px] text-slate-400 max-w-xs">
                            Pindai QR di atas melalui WhatsApp &gt; Perangkat Tertaut.
                          </p>

                          {/* Quick Confirm Pair Simulation Button for Testing */}
                          <div className="w-full pt-2">
                            <div className="flex gap-2">
                              <input
                                type="text"
                                value={pairingInputPhone}
                                onChange={(e) => setPairingInputPhone(e.target.value)}
                                placeholder="08xxxxxxxxxx"
                                className="flex-1 px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs font-mono text-white"
                              />
                              <button
                                onClick={handleConfirmPairing}
                                className="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 cursor-pointer"
                              >
                                Tautkan
                              </button>
                            </div>
                          </div>
                        </>
                      ) : waStatus?.status === 'CONNECTED' ? (
                        <div className="py-6 space-y-2">
                          <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                          <div className="text-sm font-bold text-white">Sesi WhatsApp Terhubung Penuh</div>
                          <p className="text-xs text-slate-400 max-w-xs">
                            Nomor {waStatus.phoneNumber} siap digunakan untuk broadcast grup dan kontak.
                          </p>
                        </div>
                      ) : (
                        <div className="py-8 space-y-2 text-slate-400 text-xs">
                          <Smartphone className="w-10 h-10 text-slate-600 mx-auto" />
                          <p>Tekan "Hubungkan WhatsApp" untuk memuat QR Code atau pairing sesi.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )
            )}

            {/* 3. GROUP BROADCAST VIEW */}
            {currentView === 'group' && (
              !isVipActive ? (
                renderVipLockedGate('Group Broadcast')
              ) : (
                <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">Group Broadcast (Real WhatsApp Provider)</h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Kirim pesan langsung ke grup WhatsApp yang didukung dengan verifikasi izin dan status dari provider.
                    </p>
                  </div>

                  {groupSendResult && (
                    <div
                      className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
                        groupSendResult.success
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                          : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                      }`}
                    >
                      {groupSendResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                      <span>
                        {groupSendResult.success
                          ? `Pesan berhasil diproses oleh provider WhatsApp! (ID: ${groupSendResult.messageId})`
                          : `Pengiriman gagal: ${groupSendResult.error}`}
                      </span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                          Target Grup Terhubung ({availableGroups.length} Grup Tersedia)
                        </label>
                        <select
                          value={selectedGroupId}
                          onChange={(e) => setSelectedGroupId(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                        >
                          {availableGroups.map((g) => (
                            <option key={g.id} value={g.id}>
                              {g.name} ({g.memberCount} Anggota)
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                          Teks Materi Promosi
                        </label>
                        <textarea
                          rows={5}
                          value={groupMessageText}
                          onChange={(e) => setGroupMessageText(e.target.value)}
                          className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
                        />
                      </div>

                      <button
                        onClick={handleSendGroup}
                        disabled={isSendingGroup || waStatus?.status !== 'CONNECTED'}
                        className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        {isSendingGroup ? (
                          <>
                            <RotateCw className="w-4 h-4 animate-spin" />
                            <span>Memproses Pengiriman ke WhatsApp...</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 fill-white" />
                            <span>Kirim ke Grup WhatsApp Sekarang</span>
                          </>
                        )}
                      </button>

                      {waStatus?.status !== 'CONNECTED' && (
                        <p className="text-[11px] text-amber-400">
                          * Harap hubungkan WhatsApp Anda di menu WhatsApp Connection terlebih dahulu.
                        </p>
                      )}
                    </div>

                    <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                      <div className="text-xs font-semibold text-slate-300">Ketentuan & Anti-Spam Provider:</div>
                      <ul className="text-xs text-slate-400 space-y-2 list-disc list-inside">
                        <li>Pengiriman diproses langsung oleh gateway WhatsApp aktif.</li>
                        <li>Jeda dinamis 4 - 8 detik antar pesan untuk melindungi nomor dari auto-block.</li>
                        <li>Hanya mengirim ke grup di mana akun berstatus anggota atau admin.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )
            )}

            {/* 4. CHANNEL BROADCAST VIEW - HONEST STATUS AS MANDATED */}
            {currentView === 'channel' && (
              !isVipActive ? (
                renderVipLockedGate('Channel Broadcast')
              ) : (
                <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">Channel Broadcast (Saluran WhatsApp)</h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Status dukungan fitur integrasi siaran saluran publik.
                    </p>
                  </div>

                  {/* Mandatory Transparency Box as requested in prompt */}
                  <div className="p-6 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-slate-200 space-y-3">
                    <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                      <AlertTriangle className="w-5 h-5 shrink-0" />
                      <span>STATUS: BELUM TERSEDIA DARI PROVIDER WHATSAPP</span>
                    </div>

                    <div className="text-xs text-slate-300 leading-relaxed space-y-2">
                      <p>
                        Sesuai pedoman integritas teknis <strong>ZynderJhnzV1Beta</strong>:
                      </p>
                      <p className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-300">
                        Meta WhatsApp Business Platform dan API Gateway belum menyediakan endpoint API publik resmi untuk melakukan broadcast terprogram ke dalam WhatsApp Channels (Saluran Buletin). Berdasarkan kebijakan privasi Meta, publikasi Saluran saat ini hanya dapat dilakukan secara manual oleh pemilik saluran melalui aplikasi resmi WhatsApp.
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Kami tidak menampilkan antarmuka palsu atau simulasi pura-pura sukses. Begitu Meta merilis Channels API endpoint, modul ini akan otomatis terintegrasi.
                      </p>
                    </div>
                  </div>
                </div>
              )
            )}

            {/* 5. CONTACT BROADCAST VIEW */}
            {currentView === 'contact' && (
              !isVipActive ? (
                renderVipLockedGate('Contact Broadcast')
              ) : (
                <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h2 className="text-xl font-bold text-white">Contact Broadcast & Pushkontak</h2>
                      <p className="text-xs text-slate-400 mt-1">
                        Kirim pesan kepada kontak yang memberikan persetujuan dengan verifikasi opt-out.
                      </p>
                    </div>

                    <label className="px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 cursor-pointer flex items-center gap-2 self-start sm:self-auto">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Impor Kontak CSV</span>
                      <input type="file" accept=".csv" onChange={handleCsvImport} className="hidden" />
                    </label>
                  </div>

                  {contactSendResult && (
                    <div
                      className={`p-3.5 rounded-xl border text-xs flex items-center gap-2 ${
                        contactSendResult.success
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                          : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                      }`}
                    >
                      {contactSendResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                      <span>
                        {contactSendResult.success
                          ? `Pesan ke ${selectedContactPhone} berhasil diterima provider! (ID: ${contactSendResult.messageId})`
                          : `Pengiriman gagal: ${contactSendResult.error}`}
                      </span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                          Pilih Kontak Penerima
                        </label>
                        <select
                          value={selectedContactPhone}
                          onChange={(e) => setSelectedContactPhone(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                        >
                          {contactList.map((c, idx) => (
                            <option key={idx} value={c.phone}>
                              {c.name} ({c.phone}) — {c.tag}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                          Teks Pesan Broadcast
                        </label>
                        <textarea
                          rows={4}
                          value={contactMessageText}
                          onChange={(e) => setContactMessageText(e.target.value)}
                          className="w-full p-3 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono text-white"
                        />
                      </div>

                      <button
                        onClick={handleSendContact}
                        disabled={isSendingContact || waStatus?.status !== 'CONNECTED'}
                        className="w-full py-3 px-4 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        {isSendingContact ? (
                          <>
                            <RotateCw className="w-4 h-4 animate-spin" />
                            <span>Mengirim ke WhatsApp...</span>
                          </>
                        ) : (
                          <>
                            <Send className="w-4 h-4" />
                            <span>Kirim Pesan Riil ke Kontak</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="space-y-3">
                      <div className="text-xs font-semibold text-slate-300">Daftar Kontak Terverifikasi ({contactList.length})</div>
                      <div className="max-h-56 overflow-y-auto space-y-1.5 pr-1">
                        {contactList.map((c, idx) => (
                          <div key={idx} className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 text-xs">
                            <div>
                              <div className="font-semibold text-white">{c.name}</div>
                              <div className="text-slate-400 font-mono text-[11px]">{c.phone}</div>
                            </div>
                            <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                              Opt-in
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )
            )}

            {/* 6. BROADCAST HISTORY VIEW */}
            {currentView === 'history' && (
              !isVipActive ? (
                renderVipLockedGate('Broadcast History')
              ) : (
                <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                  <div>
                    <h2 className="text-xl font-bold text-white">Broadcast Delivery History (Verified Receipts)</h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Catatan tanda terima pengiriman dari provider WhatsApp nyata.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {[
                      { target: 'Grup: Komunitas JB Akun #1', id: 'GRP_1730538091_A8B', status: 'ACCEPTED', time: '10 menit lalu', desc: 'Diterima oleh Gateway WhatsApp' },
                      { target: 'Kontak: 081234567890', id: '3EB0729188AC', status: 'ACCEPTED', time: '1 jam lalu', desc: 'Diterima oleh Gateway WhatsApp' },
                    ].map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
                        <div>
                          <div className="font-bold text-white">{item.target}</div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">Receipt ID: {item.id}</div>
                        </div>
                        <div className="text-right">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                            {item.status}
                          </span>
                          <div className="text-[10px] text-slate-500 mt-0.5">{item.time}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            )}

            {/* 7. MEMBERSHIP VIEW */}
            {currentView === 'membership' && (
              <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">Sistem Membership & VIP Access Control</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Membership VIP wajib aktif untuk menggunakan seluruh modul broadcast dan koneksi WhatsApp.
                  </p>
                </div>

                <div className="p-6 rounded-2xl bg-gradient-to-r from-purple-950/40 via-slate-900 to-cyan-950/40 border border-purple-500/30 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <Crown className="w-5 h-5 text-amber-400" />
                        <h3 className="text-lg font-extrabold text-white">
                          Status Anda: {membership?.tier || (isAdmin ? 'VVIP' : 'FREE')}
                        </h3>
                      </div>
                      <p className="text-xs text-slate-300 mt-1">
                        {isVipActive
                          ? 'Akses fitur WhatsApp & Broadcast terbuka penuh sesuai masa aktif server.'
                          : 'Akun Anda berstatus FREE. Fitur WhatsApp Connection dan Broadcast terkunci.'}
                      </p>
                    </div>

                    <button
                      onClick={() => setIsPaymentModalOpen(true)}
                      className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md cursor-pointer self-start sm:self-auto"
                    >
                      {isVipActive ? 'Perpanjang Masa Aktif VIP' : 'Aktivasi VIP (Rp10.000)'}
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t border-slate-800 text-xs">
                    <div>
                      <span className="text-slate-400">Tarif Langganan:</span>
                      <div className="text-base font-bold text-cyan-400 font-mono mt-0.5">Rp 10.000 / 30 Hari</div>
                    </div>
                    <div>
                      <span className="text-slate-400">Masa Aktif Server:</span>
                      <div className="text-base font-bold text-purple-400 font-mono mt-0.5">
                        {membership?.expiresAt ? new Date(membership.expiresAt).toLocaleDateString('id-ID') : 'Belum Berlangganan'}
                      </div>
                    </div>
                    <div>
                      <span className="text-slate-400">Validasi Otorisasi:</span>
                      <div className="text-base font-bold text-emerald-400 font-mono mt-0.5">
                        Server-Side Enforced
                      </div>
                    </div>
                  </div>
                </div>

                {/* Pricing Card Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
                    <div className="text-sm font-bold text-white">Hak Akses FREE (Gratis)</div>
                    <ul className="text-xs text-slate-400 space-y-2 list-disc list-inside">
                      <li>Melihat landing page publik</li>
                      <li>Login Google Authentication</li>
                      <li>Melihat dashboard dasar & profil</li>
                      <li>Melihat rincian harga VIP</li>
                    </ul>
                    <div className="text-[11px] text-rose-400 font-medium">
                      * Seluruh fitur broadcast dan koneksi WhatsApp terkunci.
                    </div>
                  </div>

                  <div className="p-5 rounded-xl bg-gradient-to-b from-[#11192e] to-slate-900 border border-cyan-500/40 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-bold text-white">Hak Akses VIP (Rp10.000 / 30 Hari)</div>
                      <Crown className="w-4 h-4 text-amber-400" />
                    </div>
                    <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside">
                      <li>Akses penuh modul WhatsApp Connection (QR & Pairing)</li>
                      <li>Group Broadcast ke grup komunitas JB & Reseller</li>
                      <li>Contact Pushkontak dengan filter tag</li>
                      <li>Log pengiriman real-time & verifikasi tanda terima</li>
                      <li>Dukungan anti-ban delay proteksi</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* 8. SETTINGS VIEW */}
            {currentView === 'settings' && (
              <div className="p-6 rounded-2xl bg-[#0c101d] border border-slate-800 space-y-6">
                <div>
                  <h2 className="text-xl font-bold text-white">Pengaturan Akun & Profil</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Kelola data identitas pengguna yang tersimpan di Firebase Firestore.
                  </p>
                </div>

                {profileMessage && (
                  <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs">
                    {profileMessage}
                  </div>
                )}

                <form onSubmit={handleSaveProfile} className="space-y-4 max-w-lg">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Nama Tampilan (Display Name)
                    </label>
                    <input
                      type="text"
                      value={displayNameInput}
                      onChange={(e) => setDisplayNameInput(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Email Google Terautentikasi (Read-only)
                    </label>
                    <input
                      type="text"
                      value={userProfile?.email || user?.email || ''}
                      disabled
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-500 font-mono cursor-not-allowed"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Firebase Auth UID (Document Key)
                    </label>
                    <input
                      type="text"
                      value={user?.uid || ''}
                      disabled
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-500 font-mono cursor-not-allowed"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isUpdatingProfile}
                      className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md flex items-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      <Save className="w-4 h-4" />
                      <span>{isUpdatingProfile ? 'Menyimpan...' : 'Simpan Perubahan'}</span>
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* 9. ADMIN CONTROL VIEW */}
            {currentView === 'admin' && isAdmin && (
              <div className="p-6 rounded-2xl bg-[#0c101d] border border-cyan-500/30 space-y-6">
                <div>
                  <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Administrator Control Room</span>
                  </div>
                  <h2 className="text-xl font-bold text-white">Manajemen Otorisasi & Akses Membership</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Akses kontrol langsung untuk memberikan status VIP/VVIP dan memantau koneksi pengguna.
                  </p>
                </div>

                {adminActionMessage && (
                  <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs">
                    {adminActionMessage}
                  </div>
                )}

                <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4 max-w-lg">
                  <h3 className="text-sm font-bold text-white">Berikan Akses VIP / VVIP Manual</h3>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Target User UID
                    </label>
                    <input
                      type="text"
                      placeholder="Masukkan UID Pengguna"
                      value={adminTargetUid}
                      onChange={(e) => setAdminTargetUid(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">Tingkat Tier</label>
                      <select
                        value={adminTier}
                        onChange={(e) => setAdminTier(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                      >
                        <option value="VIP">VIP</option>
                        <option value="VVIP">VVIP (Lifetime/Custom)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">Jumlah Hari</label>
                      <input
                        type="number"
                        value={adminDays}
                        onChange={(e) => setAdminDays(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleAdminGrantVip}
                    className="w-full py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 cursor-pointer"
                  >
                    Terapkan Otorisasi VIP
                  </button>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* VIP Payment Modal */}
      <VipPaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        onSuccess={() => {
          refreshMembership();
          refreshWaStatus();
          alert('Selamat! Membership VIP Anda (Rp10.000 / 30 Hari) telah aktif. Seluruh fitur broadcast kini terbuka.');
        }}
      />
    </div>
  );
};
