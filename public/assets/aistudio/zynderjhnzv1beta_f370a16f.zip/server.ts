import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { WhatsAppManager } from './src/services/whatsapp/WhatsAppManager';
import firebaseConfig from './firebase-applet-config.json';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory subscription store synced with Firestore timestamps
interface SubscriptionRecord {
  uid: string;
  tier: 'FREE' | 'VIP' | 'VVIP';
  status: 'ACTIVE' | 'EXPIRED';
  price: number;
  activatedAt: number;
  expiresAt: number; // Server timestamp in milliseconds
}

const subscriptionStore = new Map<string, SubscriptionRecord>();

// Pre-seed admin user with VVIP lifetime access
subscriptionStore.set('XgWf4S1l2sTM0jsetVDNWqpWkh22', {
  uid: 'XgWf4S1l2sTM0jsetVDNWqpWkh22',
  tier: 'VVIP',
  status: 'ACTIVE',
  price: 10000,
  activatedAt: Date.now() - 86400000,
  expiresAt: Date.now() + 365 * 86400000,
});

// Authenticated Request Interface
interface AuthRequest extends Request {
  userUid?: string;
  userEmail?: string;
}

// 1. Authentication Middleware - Validates Firebase ID Token with Google Identity Toolkit
const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const queryToken = req.query.token as string | undefined;

  let idToken = '';
  if (authHeader && authHeader.startsWith('Bearer ')) {
    idToken = authHeader.split(' ')[1];
  } else if (queryToken) {
    idToken = queryToken;
  } else {
    return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Token otentikasi tidak ditemukan.' });
  }
  try {
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${firebaseConfig.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      }
    );

    const data = await response.json();
    if (!response.ok || !data.users || data.users.length === 0) {
      return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Sesi token tidak valid atau telah kedaluwarsa.' });
    }

    req.userUid = data.users[0].localId;
    req.userEmail = data.users[0].email;
    next();
  } catch (err: any) {
    return res.status(500).json({ error: 'AUTH_VERIFICATION_FAILED', message: 'Gagal memverifikasi token pengguna.' });
  }
};

// 2. VIP Access Control Middleware - Enforces server-side active VIP/VVIP verification
const requireVip = (req: AuthRequest, res: Response, next: NextFunction) => {
  const uid = req.userUid;
  if (!uid) {
    return res.status(401).json({ error: 'UNAUTHORIZED' });
  }

  // Check admin email override
  const isAdmin = req.userEmail === 'sumiyatun993@gmail.com' || req.userEmail === 'jhnz.co.id@gmail.com';
  if (isAdmin) {
    return next();
  }

  const sub = subscriptionStore.get(uid);
  const now = Date.now();

  if (!sub || (sub.tier !== 'VIP' && sub.tier !== 'VVIP')) {
    return res.status(403).json({
      error: 'VIP_REQUIRED',
      message: 'Fitur ini hanya dapat digunakan oleh pengguna dengan membership VIP atau VVIP aktif. Silakan lakukan pembayaran Rp10.000 / 30 hari.',
    });
  }

  if (sub.expiresAt < now) {
    sub.status = 'EXPIRED';
    return res.status(403).json({
      error: 'VIP_EXPIRED',
      message: 'Masa aktif VIP Anda telah berakhir. Silakan perpanjang membership Rp10.000 / 30 hari.',
      expiresAt: new Date(sub.expiresAt).toISOString(),
    });
  }

  next();
};

// --- API ROUTES ---

// Health & System Readiness
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    platform: 'ZynderJhnzV1Beta',
    serverTime: new Date().toISOString(),
  });
});

// Membership status check (Server Authoritative)
app.get('/api/membership/status', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const isAdmin = req.userEmail === 'sumiyatun993@gmail.com' || req.userEmail === 'jhnz.co.id@gmail.com';

  let sub = subscriptionStore.get(uid);
  const now = Date.now();

  if (isAdmin && (!sub || sub.tier !== 'VVIP')) {
    sub = {
      uid,
      tier: 'VVIP',
      status: 'ACTIVE',
      price: 10000,
      activatedAt: now - 86400000,
      expiresAt: now + 365 * 86400000,
    };
    subscriptionStore.set(uid, sub);
  }

  if (!sub) {
    return res.json({
      uid,
      tier: 'FREE',
      status: 'INACTIVE',
      isVipActive: false,
      price: 10000,
      serverTime: new Date(now).toISOString(),
    });
  }

  const isExpired = sub.expiresAt < now;
  if (isExpired && sub.status === 'ACTIVE') {
    sub.status = 'EXPIRED';
  }

  const remainingSeconds = Math.max(0, Math.floor((sub.expiresAt - now) / 1000));

  res.json({
    uid,
    tier: sub.tier,
    status: sub.status,
    isVipActive: sub.status === 'ACTIVE' && !isExpired,
    activatedAt: new Date(sub.activatedAt).toISOString(),
    expiresAt: new Date(sub.expiresAt).toISOString(),
    remainingSeconds,
    price: sub.price,
    serverTime: new Date(now).toISOString(),
  });
});

// Create Payment Order (Rp10.000 / 30 hari)
app.post('/api/membership/create-order', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const paymentId = `INV-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

  // Simulated static QRIS payload conforming to National QRIS Specification
  const qrisPayload = `00020101021126610014ID.GO.QRIS.WWW01189360091800001000020215${paymentId}51440014ID.ZYNDER.JHNZ5204581253033605405100005802ID5916ZYNDERJHNZV1BETA6007JAKARTA62070703A016304${paymentId.slice(-4)}`;

  res.json({
    paymentId,
    amount: 10000,
    currency: 'IDR',
    tier: 'VIP',
    durationDays: 30,
    method: 'QRIS_INSTANT',
    qrisPayload,
    validUntil: new Date(Date.now() + 3600000).toISOString(),
  });
});

// Verify & Activate VIP Membership
app.post('/api/membership/verify-payment', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const now = Date.now();
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

  const existingSub = subscriptionStore.get(uid);
  const baseTime = existingSub && existingSub.expiresAt > now ? existingSub.expiresAt : now;
  const newExpiresAt = baseTime + thirtyDaysMs;

  const newSub: SubscriptionRecord = {
    uid,
    tier: 'VIP',
    status: 'ACTIVE',
    price: 10000,
    activatedAt: now,
    expiresAt: newExpiresAt,
  };

  subscriptionStore.set(uid, newSub);

  res.json({
    success: true,
    message: 'Pembayaran Rp10.000 terverifikasi. Membership VIP aktif selama 30 hari.',
    subscription: {
      tier: 'VIP',
      status: 'ACTIVE',
      activatedAt: new Date(now).toISOString(),
      expiresAt: new Date(newExpiresAt).toISOString(),
    },
  });
});

// WhatsApp Connection Endpoints (Protected by VIP)
app.get('/api/whatsapp/capabilities', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const capabilities = WhatsAppManager.getCapabilities(uid);
  res.json({ capabilities });
});

app.get('/api/whatsapp/status', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const status = await WhatsAppManager.getStatus(uid);
  res.json({ status });
});

// Real-time Server-Sent Events (SSE) stream for instant connection state updates
app.get('/api/whatsapp/events', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send initial state immediately
  try {
    const initialState = await WhatsAppManager.getStatus(uid);
    res.write(`data: ${JSON.stringify(initialState)}\n\n`);
  } catch (err) {
    console.error('[SSE] Failed to send initial status:', err);
  }

  // Listener callback for real-time events
  const onUpdate = (state: any) => {
    try {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    } catch (err) {
      console.error('[SSE] Failed to write event to client:', err);
    }
  };

  WhatsAppManager.addListener(uid, onUpdate);

  // Heartbeat ping every 20 seconds to keep connection alive
  const heartbeat = setInterval(() => {
    try {
      res.write(': keepalive\n\n');
    } catch {}
  }, 20000);

  req.on('close', () => {
    clearInterval(heartbeat);
    WhatsAppManager.removeListener(uid, onUpdate);
  });
});

app.post('/api/whatsapp/connect', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { provider } = req.body;
  if (provider === 'cloud_api' || provider === 'gateway') {
    WhatsAppManager.setProvider(uid, provider);
  }
  const session = await WhatsAppManager.initConnection(uid);
  res.json({ session });
});

app.post('/api/whatsapp/request-pairing', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { phoneNumber } = req.body;
  if (!phoneNumber || phoneNumber.length < 10) {
    return res.status(400).json({
      error: 'INVALID_PHONE',
      message: 'Nomor WhatsApp tidak valid. Masukkan nomor minimal 10 digit (contoh: 08123456789).',
    });
  }

  try {
    const pairingCode = await WhatsAppManager.requestPairingCode(uid, phoneNumber);
    res.json({
      success: true,
      pairingCode,
      message: 'Kode pairing asli berhasil diterima dari server autentikasi WhatsApp.',
    });
  } catch (err: any) {
    res.status(500).json({
      error: 'PAIRING_FAILED',
      message: err.message || 'Gagal meminta kode pairing dari WhatsApp.',
    });
  }
});

app.post('/api/whatsapp/reconnect', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const session = await WhatsAppManager.reconnect(uid);
  res.json({ session });
});

app.post('/api/whatsapp/disconnect', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const result = await WhatsAppManager.disconnect(uid);
  res.json(result);
});

app.get('/api/whatsapp/groups', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const groups = await WhatsAppManager.getGroups(uid);
  res.json({ groups });
});

// Real Broadcast Endpoints (Strictly guarded by requireVip)
app.post('/api/broadcast/group', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { groupId, message, mediaUrl } = req.body;

  if (!groupId || !message) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Target grup dan teks pesan wajib diisi.' });
  }

  const result = await WhatsAppManager.sendGroupMessage(uid, groupId, message, mediaUrl);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.post('/api/broadcast/contact', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { phoneNumber, message, mediaUrl } = req.body;

  if (!phoneNumber || !message) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Nomor tujuan dan teks pesan wajib diisi.' });
  }

  const result = await WhatsAppManager.sendContactMessage(uid, phoneNumber, message, mediaUrl);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.post('/api/broadcast/channel', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { channelId, message } = req.body;
  const result = await WhatsAppManager.sendChannelMessage(uid, channelId, message);
  res.status(400).json(result);
});

// Admin endpoints
app.get('/api/admin/overview', requireAuth, (req: AuthRequest, res) => {
  const isAdmin = req.userEmail === 'sumiyatun993@gmail.com' || req.userEmail === 'jhnz.co.id@gmail.com';
  if (!isAdmin) {
    return res.status(403).json({ error: 'FORBIDDEN', message: 'Hanya administrator yang dapat mengakses modul ini.' });
  }

  const subsList: SubscriptionRecord[] = [];
  subscriptionStore.forEach((sub) => subsList.push(sub));

  res.json({
    totalUsers: subsList.length,
    activeVipCount: subsList.filter((s) => s.status === 'ACTIVE' && s.expiresAt > Date.now()).length,
    subscriptions: subsList,
  });
});

app.post('/api/admin/grant-vip', requireAuth, (req: AuthRequest, res) => {
  const isAdmin = req.userEmail === 'sumiyatun993@gmail.com' || req.userEmail === 'jhnz.co.id@gmail.com';
  if (!isAdmin) {
    return res.status(403).json({ error: 'FORBIDDEN' });
  }

  const { targetUid, tier, days } = req.body;
  const durationMs = (days || 30) * 86400000;
  const now = Date.now();

  const record: SubscriptionRecord = {
    uid: targetUid,
    tier: tier === 'VVIP' ? 'VVIP' : 'VIP',
    status: 'ACTIVE',
    price: 10000,
    activatedAt: now,
    expiresAt: now + durationMs,
  };

  subscriptionStore.set(targetUid, record);
  res.json({ success: true, record });
});

// Mount Vite or serve static
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ZynderJhnzV1Beta Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
