import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

// Types
export interface AdminUser {
  username: string;
  role: 'SUPER_ADMIN';
  lastLoginAt?: string;
}

export interface AdminSession {
  token: string;
  username: string;
  expiresAt: number;
  ip?: string;
  userAgent?: string;
}

export interface PaymentRecord {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  tier: 'VIP' | 'VVIP';
  amount: number;
  currency: string;
  durationDays: number;
  method: 'QRIS_MANUAL' | 'QRIS_INSTANT' | 'BANK_TRANSFER' | 'E_WALLET';
  receiptUrl?: string; // Image base64 data url or public URL
  senderName?: string;
  senderAccount?: string;
  notes?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  rejectionReason?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TelegramConfig {
  botToken: string;
  adminChatId: string;
  isActive: boolean;
  botUsername?: string;
  lastTestedAt?: string;
  lastError?: string;
}

export interface SystemSettings {
  siteName: string;
  siteDescription: string;
  qrisImageUrl: string; // Base64 or image URL
  qrisManualActive: boolean;
  qiospayActive: boolean;
  vipPrice: number;
  vipDurationDays: number;
  whatsappChannelUrl: string;
  whatsappGroupUrl: string;
  adminWhatsappUrl: string;
  adminTelegramUrl: string;
  customerServiceUrl: string;
  announcementActive: boolean;
  announcementText: string;
  announcementType: 'info' | 'warning' | 'promo';
  maintenanceMode: boolean;
  maintenanceMessage: string;
  updatedAt: string;
  updatedBy: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  details: string;
  ip?: string;
  previousData?: any;
  newData?: any;
}

// In-Memory Persistent Data Store with JSON File Fallback
const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const ADMIN_STORE_FILE = path.join(DATA_DIR, 'admin_data.json');

interface StoredData {
  adminPasswordHash: string;
  telegramConfig: TelegramConfig;
  settings: SystemSettings;
  payments: PaymentRecord[];
  auditLogs: AuditLogItem[];
}

// Default initial password hash for "JhnzV1Beta"
const DEFAULT_PASSWORD_HASH = bcrypt.hashSync('JhnzV1Beta', 10);

const DEFAULT_SETTINGS: SystemSettings = {
  siteName: 'ZynderJhnzV1Beta',
  siteDescription: 'Platform WhatsApp Automation & Broadcast Canggih Berbasis Multi-Session Gateway',
  qrisImageUrl: '', // Default empty; uses standard QRIS code or custom uploaded image
  qrisManualActive: true,
  qiospayActive: false,
  vipPrice: 10000,
  vipDurationDays: 30,
  whatsappChannelUrl: 'https://whatsapp.com/channel/zynderjhnz',
  whatsappGroupUrl: 'https://chat.whatsapp.com/zynderjhnzsupport',
  adminWhatsappUrl: 'https://wa.me/6281234567890',
  adminTelegramUrl: 'https://t.me/zynderjhnz_admin',
  customerServiceUrl: 'https://wa.me/6281234567890?text=Halo%20Admin%20ZynderJhnz',
  announcementActive: true,
  announcementText: '🚀 ZynderJhnzV1Beta kini mendukung Group Member DM Broadcast dan integrasi multi-sesi WhatsApp!',
  announcementType: 'promo',
  maintenanceMode: false,
  maintenanceMessage: 'Sistem sedang dalam peningkatan performa berkala. Silakan kembali beberapa saat lagi.',
  updatedAt: new Date().toISOString(),
  updatedBy: 'System',
};

const DEFAULT_TELEGRAM_CONFIG: TelegramConfig = {
  botToken: '',
  adminChatId: '',
  isActive: false,
};

// Seed initial payments to demonstrate dashboard and approval features immediately
const SEED_PAYMENTS: PaymentRecord[] = [
  {
    id: 'INV-20261102-001',
    userId: 'usr_sample_101',
    userName: 'Budi Pratama',
    userEmail: 'budi.pratama@gmail.com',
    tier: 'VIP',
    amount: 10000,
    currency: 'IDR',
    durationDays: 30,
    method: 'QRIS_MANUAL',
    senderName: 'Budi Pratama',
    senderAccount: 'BCA 8291029182',
    notes: 'Aktivasi membership VIP 30 hari',
    status: 'PENDING',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'INV-20261102-002',
    userId: 'usr_sample_102',
    userName: 'Siti Rahmawati',
    userEmail: 'siti.rahma@yahoo.com',
    tier: 'VIP',
    amount: 10000,
    currency: 'IDR',
    durationDays: 30,
    method: 'QRIS_INSTANT',
    senderName: 'Siti Rahmawati',
    senderAccount: 'GoPay 081299887766',
    notes: 'Pembayaran QRIS instan otomatis',
    status: 'APPROVED',
    approvedBy: 'JhnzV1Beta',
    approvedAt: new Date(Date.now() - 86400000).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 1.1).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'INV-20261101-003',
    userId: 'usr_sample_103',
    userName: 'Ahmad Fauzi',
    userEmail: 'ahmad.fauzi@outlook.com',
    tier: 'VIP',
    amount: 10000,
    currency: 'IDR',
    durationDays: 30,
    method: 'BANK_TRANSFER',
    senderName: 'Ahmad Fauzi',
    senderAccount: 'Mandiri 14000998811',
    notes: 'Transfer manual ATM',
    status: 'APPROVED',
    approvedBy: 'JhnzV1Beta',
    approvedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 2.1).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
];

class AdminStoreService {
  private adminPasswordHash: string = DEFAULT_PASSWORD_HASH;
  private telegramConfig: TelegramConfig = { ...DEFAULT_TELEGRAM_CONFIG };
  private settings: SystemSettings = { ...DEFAULT_SETTINGS };
  private payments: Map<string, PaymentRecord> = new Map();
  private auditLogs: AuditLogItem[] = [];
  private activeSessions: Map<string, AdminSession> = new Map();

  // Brute force protection: IP -> { attempts: number, lockUntil: number }
  private loginRateLimiter: Map<string, { attempts: number; lockUntil: number }> = new Map();

  constructor() {
    this.loadFromFile();
    if (this.payments.size === 0) {
      SEED_PAYMENTS.forEach((p) => this.payments.set(p.id, p));
      this.saveToFile();
    }
  }

  private loadFromFile() {
    try {
      if (fs.existsSync(ADMIN_STORE_FILE)) {
        const raw = fs.readFileSync(ADMIN_STORE_FILE, 'utf-8');
        const data: StoredData = JSON.parse(raw);
        if (data.adminPasswordHash) this.adminPasswordHash = data.adminPasswordHash;
        if (data.telegramConfig) this.telegramConfig = { ...DEFAULT_TELEGRAM_CONFIG, ...data.telegramConfig };
        if (data.settings) this.settings = { ...DEFAULT_SETTINGS, ...data.settings };
        if (Array.isArray(data.payments)) {
          data.payments.forEach((p) => this.payments.set(p.id, p));
        }
        if (Array.isArray(data.auditLogs)) {
          this.auditLogs = data.auditLogs;
        }
      }
    } catch (err) {
      console.error('[AdminStore] Failed to load data from file:', err);
    }
  }

  private saveToFile() {
    try {
      const data: StoredData = {
        adminPasswordHash: this.adminPasswordHash,
        telegramConfig: this.telegramConfig,
        settings: this.settings,
        payments: Array.from(this.payments.values()),
        auditLogs: this.auditLogs.slice(-1000), // Keep last 1000 logs
      };
      fs.writeFileSync(ADMIN_STORE_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('[AdminStore] Failed to save data to file:', err);
    }
  }

  // --- RATE LIMITING ---
  checkRateLimit(ip: string): { allowed: boolean; remainingAttempts: number; retryAfterSec?: number } {
    const now = Date.now();
    const entry = this.loginRateLimiter.get(ip);
    if (!entry) {
      return { allowed: true, remainingAttempts: 5 };
    }

    if (entry.lockUntil > now) {
      const retryAfterSec = Math.ceil((entry.lockUntil - now) / 1000);
      return { allowed: false, remainingAttempts: 0, retryAfterSec };
    }

    // Reset lock if expired
    if (entry.lockUntil > 0 && entry.lockUntil <= now) {
      this.loginRateLimiter.delete(ip);
      return { allowed: true, remainingAttempts: 5 };
    }

    const remaining = Math.max(0, 5 - entry.attempts);
    return { allowed: remaining > 0, remainingAttempts: remaining };
  }

  recordLoginAttempt(ip: string, success: boolean) {
    const now = Date.now();
    let entry = this.loginRateLimiter.get(ip) || { attempts: 0, lockUntil: 0 };

    if (success) {
      this.loginRateLimiter.delete(ip);
      return;
    }

    entry.attempts += 1;
    if (entry.attempts >= 5) {
      // Lock for 15 minutes
      entry.lockUntil = now + 15 * 60 * 1000;
    }
    this.loginRateLimiter.set(ip, entry);
  }

  // --- AUTHENTICATION ---
  verifyCredentials(username: string, passwordPlain: string): boolean {
    const envAdminUser = process.env.ADMIN_USERNAME || 'JhnzV1Beta';
    if (username !== envAdminUser) {
      return false;
    }
    return bcrypt.compareSync(passwordPlain, this.adminPasswordHash);
  }

  createSession(username: string, ip?: string, userAgent?: string): string {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    this.activeSessions.set(token, {
      token,
      username,
      expiresAt,
      ip,
      userAgent,
    });
    this.logAction('LOGIN', username, `Admin ${username} berhasil masuk ke Admin Panel.`, ip);
    return token;
  }

  validateSession(token: string): AdminSession | null {
    if (!token) return null;
    const session = this.activeSessions.get(token);
    if (!session) return null;
    if (session.expiresAt < Date.now()) {
      this.activeSessions.delete(token);
      return null;
    }
    return session;
  }

  destroySession(token: string, ip?: string): boolean {
    const session = this.activeSessions.get(token);
    if (session) {
      this.logAction('LOGOUT', session.username, `Admin ${session.username} keluar dari Admin Panel.`, ip);
      this.activeSessions.delete(token);
      return true;
    }
    return false;
  }

  changePassword(oldPasswordPlain: string, newPasswordPlain: string, actor: string, ip?: string): boolean {
    if (!bcrypt.compareSync(oldPasswordPlain, this.adminPasswordHash)) {
      return false;
    }
    this.adminPasswordHash = bcrypt.hashSync(newPasswordPlain, 10);
    this.saveToFile();
    this.logAction('CHANGE_PASSWORD', actor, 'Kata sandi Admin berhasil diubah.', ip);
    return true;
  }

  // --- AUDIT LOGS ---
  logAction(action: string, actor: string, details: string, ip?: string, previousData?: any, newData?: any) {
    const item: AuditLogItem = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      action,
      actor,
      details,
      ip: ip || '127.0.0.1',
      previousData,
      newData,
    };
    this.auditLogs.unshift(item);
    if (this.auditLogs.length > 1000) {
      this.auditLogs.pop();
    }
    this.saveToFile();
  }

  getAuditLogs(limit: number = 200): AuditLogItem[] {
    return this.auditLogs.slice(0, limit);
  }

  // --- SETTINGS ---
  getSettings(): SystemSettings {
    return { ...this.settings };
  }

  updateSettings(updates: Partial<SystemSettings>, actor: string, ip?: string): SystemSettings {
    const prev = { ...this.settings };
    this.settings = {
      ...this.settings,
      ...updates,
      updatedAt: new Date().toISOString(),
      updatedBy: actor,
    };
    this.saveToFile();
    this.logAction('UPDATE_SETTINGS', actor, 'Pengaturan website & pembayaran diperbarui.', ip, prev, this.settings);
    return this.settings;
  }

  // --- TELEGRAM CONFIG ---
  getTelegramConfig(): TelegramConfig {
    return { ...this.telegramConfig };
  }

  updateTelegramConfig(config: Partial<TelegramConfig>, actor: string, ip?: string): TelegramConfig {
    this.telegramConfig = {
      ...this.telegramConfig,
      ...config,
      isActive: Boolean(config.botToken && config.adminChatId),
    };
    this.saveToFile();
    this.logAction('UPDATE_TELEGRAM_CONFIG', actor, 'Konfigurasi Telegram Bot diperbarui.', ip);
    return this.telegramConfig;
  }

  async sendTelegramMessage(text: string, replyMarkup?: any): Promise<{ success: boolean; error?: string }> {
    if (!this.telegramConfig.botToken || !this.telegramConfig.adminChatId) {
      return { success: false, error: 'Telegram Bot Token atau Chat ID belum dikonfigurasi.' };
    }

    try {
      const url = `https://api.telegram.org/bot${this.telegramConfig.botToken}/sendMessage`;
      const body: any = {
        chat_id: this.telegramConfig.adminChatId,
        text,
        parse_mode: 'HTML',
      };
      if (replyMarkup) {
        body.reply_markup = replyMarkup;
      }

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!data.ok) {
        return { success: false, error: data.description || 'Gagal mengirim pesan ke Telegram' };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Koneksi ke server Telegram gagal.' };
    }
  }

  async notifyNewPayment(payment: PaymentRecord) {
    if (!this.telegramConfig.isActive) return;

    const text = `🔔 <b>PEMBAYARAN BARU MASUK!</b>\n\n` +
      `<b>ID Transaksi:</b> <code>${payment.id}</code>\n` +
      `<b>Nama:</b> ${payment.userName}\n` +
      `<b>Email:</b> ${payment.userEmail}\n` +
      `<b>Paket:</b> ${payment.tier} (${payment.durationDays} Hari)\n` +
      `<b>Jumlah:</b> Rp ${payment.amount.toLocaleString('id-ID')}\n` +
      `<b>Metode:</b> ${payment.method}\n` +
      `<b>Pengirim:</b> ${payment.senderName || '-'} (${payment.senderAccount || '-'})\n` +
      `<b>Waktu:</b> ${new Date(payment.createdAt).toLocaleString('id-ID')}\n\n` +
      `Silakan approve atau reject melalui dashboard /ZIN atau tombol di bawah ini:`;

    const replyMarkup = {
      inline_keyboard: [
        [
          { text: '✅ Setujui (Approve)', callback_data: `approve_${payment.id}` },
          { text: '❌ Tolak (Reject)', callback_data: `reject_${payment.id}` },
        ],
      ],
    };

    await this.sendTelegramMessage(text, replyMarkup);
  }

  // --- PAYMENTS MANAGEMENT ---
  getPayments(): PaymentRecord[] {
    return Array.from(this.payments.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  getPaymentById(id: string): PaymentRecord | undefined {
    return this.payments.get(id);
  }

  createPayment(payment: Omit<PaymentRecord, 'status' | 'createdAt' | 'updatedAt'>): PaymentRecord {
    const record: PaymentRecord = {
      ...payment,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.payments.set(record.id, record);
    this.saveToFile();
    // Trigger Telegram notification
    this.notifyNewPayment(record).catch((e) => console.error('[Telegram Notify Error]:', e));
    return record;
  }

  approvePayment(id: string, actor: string, ip?: string): { success: boolean; payment?: PaymentRecord; message: string } {
    const payment = this.payments.get(id);
    if (!payment) {
      return { success: false, message: 'Transaksi pembayaran tidak ditemukan.' };
    }

    if (payment.status === 'APPROVED') {
      return { success: false, payment, message: 'Transaksi ini telah disetujui sebelumnya (Idempotent).' };
    }

    payment.status = 'APPROVED';
    payment.approvedBy = actor;
    payment.approvedAt = new Date().toISOString();
    payment.updatedAt = new Date().toISOString();

    this.payments.set(id, payment);
    this.saveToFile();

    this.logAction(
      'APPROVE_PAYMENT',
      actor,
      `Pembayaran ${payment.id} untuk user ${payment.userName} (${payment.userEmail}) sebesar Rp ${payment.amount.toLocaleString('id-ID')} disetujui.`,
      ip,
      { status: 'PENDING' },
      { status: 'APPROVED', approvedBy: actor }
    );

    // Send Telegram Notification
    if (this.telegramConfig.isActive) {
      this.sendTelegramMessage(
        `✅ <b>PEMBAYARAN DISETUJUI</b>\n\nID: <code>${payment.id}</code>\nPengguna: ${payment.userName}\nStatus: VIP Aktif (${payment.durationDays} hari)\nDisetujui oleh: ${actor}`
      ).catch(() => {});
    }

    return { success: true, payment, message: 'Pembayaran berhasil disetujui dan status VIP diaktifkan.' };
  }

  rejectPayment(id: string, reason: string, actor: string, ip?: string): { success: boolean; payment?: PaymentRecord; message: string } {
    const payment = this.payments.get(id);
    if (!payment) {
      return { success: false, message: 'Transaksi pembayaran tidak ditemukan.' };
    }

    if (payment.status === 'APPROVED') {
      return { success: false, message: 'Transaksi yang sudah disetujui tidak dapat ditolak.' };
    }

    payment.status = 'REJECTED';
    payment.rejectionReason = reason || 'Bukti transfer tidak valid atau belum masuk.';
    payment.rejectedBy = actor;
    payment.rejectedAt = new Date().toISOString();
    payment.updatedAt = new Date().toISOString();

    this.payments.set(id, payment);
    this.saveToFile();

    this.logAction(
      'REJECT_PAYMENT',
      actor,
      `Pembayaran ${payment.id} untuk user ${payment.userName} ditolak dengan alasan: "${payment.rejectionReason}".`,
      ip,
      { status: 'PENDING' },
      { status: 'REJECTED', reason: payment.rejectionReason }
    );

    // Send Telegram Notification
    if (this.telegramConfig.isActive) {
      this.sendTelegramMessage(
        `❌ <b>PEMBAYARAN DITOLAK</b>\n\nID: <code>${payment.id}</code>\nPengguna: ${payment.userName}\nAlasan: ${payment.rejectionReason}\nDitolak oleh: ${actor}`
      ).catch(() => {});
    }

    return { success: true, payment, message: 'Pembayaran berhasil ditolak.' };
  }
}

export const AdminStore = new AdminStoreService();
