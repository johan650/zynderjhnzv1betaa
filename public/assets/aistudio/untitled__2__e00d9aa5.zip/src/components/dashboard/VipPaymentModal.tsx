import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Crown,
  CheckCircle2,
  QrCode,
  ShieldCheck,
  Loader2,
  Copy,
  Check,
  Upload,
  Image as ImageIcon,
  Send,
  FileCheck,
} from 'lucide-react';
import { ApiClient } from '../../services/apiClient';

interface VipPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const VipPaymentModal: React.FC<VipPaymentModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'qris' | 'manual'>('qris');
  const [paymentData, setPaymentData] = useState<{
    paymentId: string;
    amount: number;
    qrisPayload: string;
  } | null>(null);
  const [publicSettings, setPublicSettings] = useState<{
    vipPrice: number;
    vipDurationDays: number;
    qrisImageUrl: string;
    qrisManualActive: boolean;
  }>({
    vipPrice: 10000,
    vipDurationDays: 30,
    qrisImageUrl: '',
    qrisManualActive: true,
  });

  const [copied, setCopied] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Manual payment form fields
  const [senderName, setSenderName] = useState('');
  const [senderAccount, setSenderAccount] = useState('');
  const [notes, setNotes] = useState('');
  const [receiptBase64, setReceiptBase64] = useState<string>('');
  const [isSubmittingManual, setIsSubmittingManual] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load payment details & public settings when modal opens
  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      setErrorMessage(null);
      setSuccessNotice(null);

      Promise.all([
        ApiClient.createPaymentOrder(),
        ApiClient.getPublicSettings().catch(() => null),
      ])
        .then(([orderData, settingsData]) => {
          setPaymentData(orderData);
          if (settingsData) {
            setPublicSettings({
              vipPrice: settingsData.vipPrice || 10000,
              vipDurationDays: settingsData.vipDurationDays || 30,
              qrisImageUrl: settingsData.qrisImageUrl || '',
              qrisManualActive: settingsData.qrisManualActive !== false,
            });
          }
        })
        .catch((err) => {
          setErrorMessage(err.message || 'Gagal memuat instruksi pembayaran.');
        })
        .finally(() => setLoading(false));
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopyQris = () => {
    if (paymentData?.qrisPayload) {
      navigator.clipboard.writeText(paymentData.qrisPayload);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleConfirmInstantPayment = async () => {
    if (!paymentData) return;
    setIsVerifying(true);
    setErrorMessage(null);

    try {
      await ApiClient.verifyPayment(paymentData.paymentId);
      onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Verifikasi pembayaran instan gagal.');
    } finally {
      setIsVerifying(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('File harus berupa gambar (JPG, PNG, WebP).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMessage('Ukuran gambar maksimal 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setReceiptBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitManualProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName.trim() || !senderAccount.trim()) {
      setErrorMessage('Nama pengirim dan nomor rekening/e-wallet pengirim wajib diisi.');
      return;
    }

    setIsSubmittingManual(true);
    setErrorMessage(null);

    try {
      const res = await ApiClient.submitManualPayment({
        paymentId: paymentData?.paymentId,
        senderName: senderName.trim(),
        senderAccount: senderAccount.trim(),
        notes: notes.trim(),
        receiptUrl: receiptBase64,
        amount: publicSettings.vipPrice,
        durationDays: publicSettings.vipDurationDays,
        tier: 'VIP',
        method: 'QRIS_MANUAL',
      });

      setSuccessNotice(
        'Bukti transfer Anda berhasil dikirimkan! Administrator /ZIN dan Bot Telegram telah diberitahu untuk verifikasi.'
      );
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 3000);
    } catch (err: any) {
      setErrorMessage(err.message || 'Gagal mengirimkan bukti pembayaran.');
    } finally {
      setIsSubmittingManual(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-lg rounded-3xl bg-[#0c101d] border border-cyan-500/30 p-6 sm:p-7 shadow-2xl shadow-cyan-950/50 text-slate-200 max-h-[92vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Tutup jendela pembayaran"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
          <Crown className="w-4 h-4" />
          <span>Aktivasi Membership VIP</span>
        </div>

        <h3 className="text-xl font-extrabold text-white">
          Upgrade Akses VIP ZynderJhnzV1Beta
        </h3>
        <p className="mt-1 text-xs text-slate-400">
          Buka akses penuh ke WhatsApp Connection, Group Broadcast, dan Group Member DM Broadcast.
        </p>

        {/* Tab switchers */}
        <div className="mt-4 grid grid-cols-2 gap-2 p-1 bg-slate-900 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('qris')}
            className={`py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'qris'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Scan QRIS
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('manual')}
            className={`py-2 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'manual'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Upload Bukti Transfer
          </button>
        </div>

        {loading ? (
          <div className="py-12 flex flex-col items-center justify-center text-xs text-slate-400 space-y-3">
            <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
            <span>Menyiapkan tagihan pembayaran QRIS...</span>
          </div>
        ) : errorMessage ? (
          <div className="my-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {errorMessage}
          </div>
        ) : successNotice ? (
          <div className="my-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400" />
            <div className="font-bold text-sm">Pengajuan Berhasil Dikirim!</div>
            <p className="leading-relaxed opacity-90">{successNotice}</p>
          </div>
        ) : paymentData ? (
          <div className="mt-4 space-y-4">
            {/* Price Banner */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-400">Total Tagihan ({publicSettings.vipDurationDays} Hari):</span>
                <div className="text-xl font-extrabold font-mono text-cyan-400 mt-0.5">
                  Rp {publicSettings.vipPrice.toLocaleString('id-ID')}
                </div>
              </div>
              <span className="px-2.5 py-1 text-xs font-semibold rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Akses VIP Penuh
              </span>
            </div>

            {/* TAB 1: SCAN QRIS */}
            {activeTab === 'qris' && (
              <div className="space-y-4">
                {/* Real Dynamic QRIS Image or Generated code */}
                <div className="p-4 bg-white rounded-2xl flex flex-col items-center text-center shadow-lg">
                  {publicSettings.qrisImageUrl ? (
                    <div className="max-w-[220px] max-h-[220px] flex items-center justify-center overflow-hidden rounded-xl border border-slate-200">
                      <img
                        src={publicSettings.qrisImageUrl}
                        alt="QRIS ZynderJhnzV1Beta"
                        className="w-full h-full object-contain"
                      />
                    </div>
                  ) : (
                    <div className="w-48 h-48 bg-slate-950 rounded-xl p-2 flex flex-col items-center justify-center">
                      <QrCode className="w-40 h-40 text-cyan-400" />
                    </div>
                  )}

                  <div className="text-[11px] font-bold text-slate-800 mt-2">
                    QRIS NASIONAL — ZYNDERJHNZV1BETA
                  </div>
                  <div className="text-[10px] text-slate-500">
                    BCA, Mandiri, BRI, BNI, GoPay, OVO, Dana, ShopeePay, LinkAja
                  </div>
                </div>

                {/* Invoice Reference */}
                <div className="flex items-center justify-between text-xs p-2.5 rounded-lg bg-slate-900/80 border border-slate-800">
                  <span className="text-slate-400 font-mono text-[11px]">
                    No. Pesanan: {paymentData.paymentId}
                  </span>
                  <button
                    onClick={handleCopyQris}
                    className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Tersalin' : 'Salin String QRIS'}</span>
                  </button>
                </div>

                {/* Instant Verification Button */}
                <button
                  onClick={handleConfirmInstantPayment}
                  disabled={isVerifying}
                  className="w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md shadow-cyan-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  {isVerifying ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Memverifikasi Pembayaran...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Konfirmasi Pembayaran Instan (Rp {publicSettings.vipPrice.toLocaleString('id-ID')})</span>
                    </>
                  )}
                </button>
              </div>
            )}

            {/* TAB 2: MANUAL TRANSFER PROOF UPLOAD */}
            {activeTab === 'manual' && (
              <form onSubmit={handleSubmitManualProof} className="space-y-3.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Nama Pengirim (Sesuai Rekening / Akun)
                  </label>
                  <input
                    type="text"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    placeholder="Contoh: Budi Pratama"
                    required
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-500 focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Bank / E-Wallet & Nomor Akun Pengirim
                  </label>
                  <input
                    type="text"
                    value={senderAccount}
                    onChange={(e) => setSenderAccount(e.target.value)}
                    placeholder="Contoh: BCA 8291029182 / GoPay 0812998877"
                    required
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-500 focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Upload Foto / Screenshot Bukti Transfer
                  </label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageChange}
                    accept="image/*"
                    className="hidden"
                  />

                  {receiptBase64 ? (
                    <div className="relative rounded-xl border border-cyan-500/40 p-2 bg-slate-900 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img
                          src={receiptBase64}
                          alt="Pratinjau Bukti"
                          className="w-12 h-12 object-cover rounded-lg border border-slate-700"
                        />
                        <div className="text-[11px]">
                          <span className="font-semibold text-cyan-300 block">Screenshot Terlampir</span>
                          <span className="text-[10px] text-slate-500">Siap dikirimkan ke admin /ZIN</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-2.5 py-1 text-[10px] rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                      >
                        Ganti Foto
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full p-4 rounded-xl border-2 border-dashed border-slate-700 hover:border-cyan-500/50 bg-slate-900/60 flex flex-col items-center justify-center gap-1.5 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                    >
                      <Upload className="w-5 h-5 text-cyan-400" />
                      <span className="text-xs font-semibold">Pilih Gambar Bukti Transfer</span>
                      <span className="text-[10px] text-slate-500">PNG, JPG, WebP hingga 5MB</span>
                    </button>
                  )}
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                    Catatan Tambahan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Contoh: Pembayaran atas nama Budi"
                    className="w-full px-3 py-2 text-xs rounded-xl bg-slate-900 border border-slate-700 text-slate-100 placeholder-slate-500 focus:border-cyan-400"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingManual}
                  className="w-full py-3 px-4 rounded-xl text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 shadow-md shadow-cyan-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50"
                >
                  {isSubmittingManual ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Mengirim Bukti Transfer...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Kirim Bukti Pembayaran ke Admin</span>
                    </>
                  )}
                </button>
              </form>
            )}

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Verifikasi waktu server instan 30 hari penuh</span>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
