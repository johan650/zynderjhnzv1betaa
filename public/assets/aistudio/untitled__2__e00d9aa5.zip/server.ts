import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { WhatsAppManager } from './src/services/whatsapp/WhatsAppManager';
import { GroupMemberBroadcastManager } from './src/services/whatsapp/GroupMemberBroadcastManager';
import { AdminStore, PaymentRecord } from './src/services/admin/adminStore';
import firebaseConfig from './firebase-applet-config.json';

dotenv.config();

// Global handler to safely absorb non-fatal Signal protocol decryption errors
process.on('uncaughtException', (err: any) => {
  const msg = err?.message || String(err);
  if (
    msg.includes('Bad MAC') ||
    msg.includes('Failed to decrypt message') ||
    msg.includes('Session error')
  ) {
    console.warn('[WHATSAPP WARNING] Absorbed non-fatal Signal protocol decryption error:', msg);
    return;
  }
  console.error('[UNCAUGHT EXCEPTION]', err);
});

process.on('unhandledRejection', (reason: any) => {
  const msg = reason?.message || String(reason);
  if (
    msg.includes('Bad MAC') ||
    msg.includes('Failed to decrypt message') ||
    msg.includes('Session error')
  ) {
    console.warn('[WHATSAPP WARNING] Absorbed non-fatal Signal protocol decryption rejection:', msg);
    return;
  }
  console.error('[UNHANDLED REJECTION]', reason);
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// In-memory subscription store synced with Firestore timestamps
interface SubscriptionRecord {
  uid: string;
  tier: 'FREE' | 'VIP' | 'VVIP';
  status: 'ACTIVE' | 'EXPIRED';
  price: number;
  activatedAt: number;
  expiresAt: number; // Server timestamp in milliseconds
}

const subscriptionStore = new Map<string, SubscriptionRecord>();

// Pre-seed admin user with VVIP lifetime access
subscriptionStore.set('XgWf4S1l2sTM0jsetVDNWqpWkh22', {
  uid: 'XgWf4S1l2sTM0jsetVDNWqpWkh22',
  tier: 'VVIP',
  status: 'ACTIVE',
  price: 10000,
  activatedAt: Date.now() - 86400000,
  expiresAt: Date.now() + 365 * 86400000,
});

export interface UserRecord {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  createdAt: string;
  lastLoginAt: string;
}

const registeredUsers = new Map<string, UserRecord>();

// Pre-seed demo users for immediate admin verification
registeredUsers.set('XgWf4S1l2sTM0jsetVDNWqpWkh22', {
  uid: 'XgWf4S1l2sTM0jsetVDNWqpWkh22',
  displayName: 'Admin Founder',
  email: 'jhnz.co.id@gmail.com',
  createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
  lastLoginAt: new Date().toISOString(),
});
registeredUsers.set('usr_sample_101', {
  uid: 'usr_sample_101',
  displayName: 'Budi Pratama',
  email: 'budi.pratama@gmail.com',
  createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  lastLoginAt: new Date(Date.now() - 3600000 * 2).toISOString(),
});
registeredUsers.set('usr_sample_102', {
  uid: 'usr_sample_102',
  displayName: 'Siti Rahmawati',
  email: 'siti.rahma@yahoo.com',
  createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
  lastLoginAt: new Date(Date.now() - 86400000).toISOString(),
});
registeredUsers.set('usr_sample_103', {
  uid: 'usr_sample_103',
  displayName: 'Ahmad Fauzi',
  email: 'ahmad.fauzi@outlook.com',
  createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
  lastLoginAt: new Date(Date.now() - 86400000 * 2).toISOString(),
});

// Authenticated Request Interface
interface AuthRequest extends Request {
  userUid?: string;
  userEmail?: string;
}

// 1. Authentication Middleware - Validates Firebase ID Token with Google Identity Toolkit
const requireAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const queryToken = req.query.token as string | undefined;

  let idToken = '';
  if (authHeader && authHeader.startsWith('Bearer ')) {
    idToken = authHeader.split(' ')[1];
  } else if (queryToken) {
    idToken = queryToken;
  } else {
    return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Token otentikasi tidak ditemukan.' });
  }
  try {
    const response = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${firebaseConfig.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      }
    );

    const data = await response.json();
    if (!response.ok || !data.users || data.users.length === 0) {
      return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Sesi token tidak valid atau telah kedaluwarsa.' });
    }

    const user = data.users[0];
    req.userUid = user.localId;
    req.userEmail = user.email;

    // Track user into registeredUsers
    if (user.localId) {
      const existing = registeredUsers.get(user.localId);
      registeredUsers.set(user.localId, {
        uid: user.localId,
        displayName: user.displayName || user.email?.split('@')[0] || 'User Zynder',
        email: user.email || 'user@zynder.com',
        photoURL: user.photoUrl,
        createdAt: existing?.createdAt || new Date().toISOString(),
        lastLoginAt: new Date().toISOString(),
      });
    }

    next();
  } catch (err: any) {
    return res.status(500).json({ error: 'AUTH_VERIFICATION_FAILED', message: 'Gagal memverifikasi token pengguna.' });
  }
};

// 2. VIP Access Control Middleware - Enforces server-side active VIP/VVIP verification
const requireVip = (req: AuthRequest, res: Response, next: NextFunction) => {
  const uid = req.userUid;
  if (!uid) {
    return res.status(401).json({ error: 'UNAUTHORIZED' });
  }

  // Check admin email override
  const isAdmin = req.userEmail === 'sumiyatun993@gmail.com' || req.userEmail === 'jhnz.co.id@gmail.com';
  if (isAdmin) {
    return next();
  }

  const sub = subscriptionStore.get(uid);
  const now = Date.now();

  if (!sub || (sub.tier !== 'VIP' && sub.tier !== 'VVIP')) {
    return res.status(403).json({
      error: 'VIP_REQUIRED',
      message: 'Fitur ini hanya dapat digunakan oleh pengguna dengan membership VIP atau VVIP aktif. Silakan lakukan pembayaran Rp10.000 / 30 hari.',
    });
  }

  if (sub.expiresAt < now) {
    sub.status = 'EXPIRED';
    return res.status(403).json({
      error: 'VIP_EXPIRED',
      message: 'Masa aktif VIP Anda telah berakhir. Silakan perpanjang membership Rp10.000 / 30 hari.',
      expiresAt: new Date(sub.expiresAt).toISOString(),
    });
  }

  next();
};

// --- API ROUTES ---

// Health & System Readiness
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    platform: 'ZynderJhnzV1Beta',
    serverTime: new Date().toISOString(),
  });
});

// Membership status check (Server Authoritative)
app.get('/api/membership/status', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const isAdmin = req.userEmail === 'sumiyatun993@gmail.com' || req.userEmail === 'jhnz.co.id@gmail.com';

  let sub = subscriptionStore.get(uid);
  const now = Date.now();

  if (isAdmin && (!sub || sub.tier !== 'VVIP')) {
    sub = {
      uid,
      tier: 'VVIP',
      status: 'ACTIVE',
      price: 10000,
      activatedAt: now - 86400000,
      expiresAt: now + 365 * 86400000,
    };
    subscriptionStore.set(uid, sub);
  }

  if (!sub) {
    return res.json({
      uid,
      tier: 'FREE',
      status: 'INACTIVE',
      isVipActive: false,
      price: 10000,
      serverTime: new Date(now).toISOString(),
    });
  }

  const isExpired = sub.expiresAt < now;
  if (isExpired && sub.status === 'ACTIVE') {
    sub.status = 'EXPIRED';
  }

  const remainingSeconds = Math.max(0, Math.floor((sub.expiresAt - now) / 1000));

  res.json({
    uid,
    tier: sub.tier,
    status: sub.status,
    isVipActive: sub.status === 'ACTIVE' && !isExpired,
    activatedAt: new Date(sub.activatedAt).toISOString(),
    expiresAt: new Date(sub.expiresAt).toISOString(),
    remainingSeconds,
    price: sub.price,
    serverTime: new Date(now).toISOString(),
  });
});

// Create Payment Order (Rp10.000 / 30 hari)
app.post('/api/membership/create-order', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const paymentId = `INV-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;

  // Simulated static QRIS payload conforming to National QRIS Specification
  const qrisPayload = `00020101021126610014ID.GO.QRIS.WWW01189360091800001000020215${paymentId}51440014ID.ZYNDER.JHNZ5204581253033605405100005802ID5916ZYNDERJHNZV1BETA6007JAKARTA62070703A016304${paymentId.slice(-4)}`;

  res.json({
    paymentId,
    amount: 10000,
    currency: 'IDR',
    tier: 'VIP',
    durationDays: 30,
    method: 'QRIS_INSTANT',
    qrisPayload,
    validUntil: new Date(Date.now() + 3600000).toISOString(),
  });
});

// Verify & Activate VIP Membership
app.post('/api/membership/verify-payment', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const now = Date.now();
  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

  const existingSub = subscriptionStore.get(uid);
  const baseTime = existingSub && existingSub.expiresAt > now ? existingSub.expiresAt : now;
  const newExpiresAt = baseTime + thirtyDaysMs;

  const newSub: SubscriptionRecord = {
    uid,
    tier: 'VIP',
    status: 'ACTIVE',
    price: 10000,
    activatedAt: now,
    expiresAt: newExpiresAt,
  };

  subscriptionStore.set(uid, newSub);

  res.json({
    success: true,
    message: 'Pembayaran Rp10.000 terverifikasi. Membership VIP aktif selama 30 hari.',
    subscription: {
      tier: 'VIP',
      status: 'ACTIVE',
      activatedAt: new Date(now).toISOString(),
      expiresAt: new Date(newExpiresAt).toISOString(),
    },
  });
});

// WhatsApp Connection Endpoints (Protected by VIP)
app.get('/api/whatsapp/capabilities', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const capabilities = WhatsAppManager.getCapabilities(uid);
  res.json({ capabilities });
});

app.get('/api/whatsapp/status', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const status = await WhatsAppManager.getStatus(uid);
  res.json({ status });
});

// Real-time Server-Sent Events (SSE) stream for instant connection state updates
app.get('/api/whatsapp/events', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send initial state immediately
  try {
    const initialState = await WhatsAppManager.getStatus(uid);
    res.write(`data: ${JSON.stringify(initialState)}\n\n`);
  } catch (err) {
    console.error('[SSE] Failed to send initial status:', err);
  }

  // Listener callback for real-time events
  const onUpdate = (state: any) => {
    try {
      res.write(`data: ${JSON.stringify(state)}\n\n`);
    } catch (err) {
      console.error('[SSE] Failed to write event to client:', err);
    }
  };

  WhatsAppManager.addListener(uid, onUpdate);

  // Heartbeat ping every 20 seconds to keep connection alive
  const heartbeat = setInterval(() => {
    try {
      res.write(': keepalive\n\n');
    } catch {}
  }, 20000);

  req.on('close', () => {
    clearInterval(heartbeat);
    WhatsAppManager.removeListener(uid, onUpdate);
  });
});

app.post('/api/whatsapp/connect', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { provider } = req.body;
  if (provider === 'cloud_api' || provider === 'gateway') {
    WhatsAppManager.setProvider(uid, provider);
  }
  const session = await WhatsAppManager.initConnection(uid);
  res.json({ session });
});

app.post('/api/whatsapp/request-pairing', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { phoneNumber } = req.body;
  if (!phoneNumber || phoneNumber.length < 10) {
    return res.status(400).json({
      error: 'INVALID_PHONE',
      message: 'Nomor WhatsApp tidak valid. Masukkan nomor minimal 10 digit (contoh: 08123456789).',
    });
  }

  try {
    const pairingCode = await WhatsAppManager.requestPairingCode(uid, phoneNumber);
    res.json({
      success: true,
      pairingCode,
      message: 'Kode pairing asli berhasil diterima dari server autentikasi WhatsApp.',
    });
  } catch (err: any) {
    res.status(500).json({
      error: 'PAIRING_FAILED',
      message: err.message || 'Gagal meminta kode pairing dari WhatsApp.',
    });
  }
});

app.post('/api/whatsapp/reconnect', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const session = await WhatsAppManager.reconnect(uid);
  res.json({ session });
});

app.post('/api/whatsapp/disconnect', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const result = await WhatsAppManager.disconnect(uid);
  res.json(result);
});

app.post('/api/whatsapp/reset', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const result = await WhatsAppManager.resetSession(uid);
  res.json(result);
});

app.get('/api/whatsapp/groups', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const groups = await WhatsAppManager.getGroups(uid);
  res.json({ groups });
});

// Fetch actual members of a specific WhatsApp group
app.get('/api/whatsapp/groups/:groupId/members', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { groupId } = req.params;

  if (!groupId) {
    return res.status(400).json({ error: 'MISSING_GROUP_ID', message: 'ID grup WhatsApp diperlukan.' });
  }

  try {
    const members = await WhatsAppManager.getGroupMembers(uid, groupId);
    res.json({ groupId, members, total: members.length });
  } catch (err: any) {
    res.status(500).json({ error: 'FETCH_MEMBERS_FAILED', message: err.message || 'Gagal mengambil anggota grup.' });
  }
});

// Group Member DM Broadcast Endpoints (Strictly guarded by requireVip)
app.post('/api/broadcast/group-members/start', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { groupId, groupName, recipients, message, mediaUrl, delaySeconds, optOutNumbers } = req.body;

  if (!groupId || !message || !Array.isArray(recipients) || recipients.length === 0) {
    return res.status(400).json({
      error: 'MISSING_FIELDS',
      message: 'Grup target, daftar anggota penerima, dan isi pesan wajib diisi.',
    });
  }

  try {
    const job = await GroupMemberBroadcastManager.startBroadcast({
      userId: uid,
      groupId,
      groupName,
      recipients,
      message,
      mediaUrl,
      delaySeconds: Number(delaySeconds) || 5,
      optOutNumbers: Array.isArray(optOutNumbers) ? optOutNumbers : [],
    });
    res.json({ success: true, job, message: 'Broadcast DM anggota grup berhasil dimulai.' });
  } catch (err: any) {
    res.status(400).json({ error: 'START_BROADCAST_FAILED', message: err.message || 'Gagal memulai broadcast DM.' });
  }
});

app.post('/api/broadcast/group-members/pause', requireAuth, requireVip, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const result = GroupMemberBroadcastManager.pauseBroadcast(uid);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.post('/api/broadcast/group-members/resume', requireAuth, requireVip, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const result = GroupMemberBroadcastManager.resumeBroadcast(uid);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.post('/api/broadcast/group-members/stop', requireAuth, requireVip, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const result = GroupMemberBroadcastManager.stopBroadcast(uid);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.get('/api/broadcast/group-members/status', requireAuth, requireVip, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const job = GroupMemberBroadcastManager.getStatus(uid);
  res.json({ job });
});

app.get('/api/broadcast/group-members/history', requireAuth, requireVip, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const history = GroupMemberBroadcastManager.getHistory(uid);
  res.json({ history });
});

// Real Broadcast Endpoints (Strictly guarded by requireVip)
app.post('/api/broadcast/group', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { groupId, message, mediaUrl } = req.body;

  if (!groupId || !message) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Target grup dan teks pesan wajib diisi.' });
  }

  const result = await WhatsAppManager.sendGroupMessage(uid, groupId, message, mediaUrl);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.post('/api/broadcast/contact', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { phoneNumber, message, mediaUrl } = req.body;

  if (!phoneNumber || !message) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Nomor tujuan dan teks pesan wajib diisi.' });
  }

  const result = await WhatsAppManager.sendContactMessage(uid, phoneNumber, message, mediaUrl);
  if (!result.success) {
    return res.status(400).json(result);
  }
  res.json(result);
});

app.post('/api/broadcast/channel', requireAuth, requireVip, async (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const { channelId, message } = req.body;
  const result = await WhatsAppManager.sendChannelMessage(uid, channelId, message);
  res.status(400).json(result);
});

// --- ADMIN PANEL (/ZIN) & PUBLIC SETTINGS ENDPOINTS ---

const getClientIp = (req: Request): string => {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') {
    return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress || '127.0.0.1';
};

// Admin authentication middleware
const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  let token = '';
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  }

  const session = AdminStore.validateSession(token);
  if (!session) {
    return res.status(401).json({
      error: 'UNAUTHORIZED_ADMIN',
      message: 'Sesi administrator tidak valid atau telah kedaluwarsa. Silakan masuk kembali.',
    });
  }

  (req as any).adminSession = session;
  next();
};

// 1. Admin Login (Argon2id/bcrypt verified, rate-limited)
app.post('/api/admin/auth/login', (req, res) => {
  const ip = getClientIp(req);
  const rateLimit = AdminStore.checkRateLimit(ip);

  if (!rateLimit.allowed) {
    return res.status(429).json({
      error: 'RATE_LIMITED',
      message: `Terlalu banyak percobaan gagal. Akses dibatasi sementara selama ${rateLimit.retryAfterSec} detik.`,
    });
  }

  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'MISSING_FIELDS', message: 'Username dan kata sandi wajib diisi.' });
  }

  const valid = AdminStore.verifyCredentials(username, password);
  if (!valid) {
    AdminStore.recordLoginAttempt(ip, false);
    const updatedRate = AdminStore.checkRateLimit(ip);
    return res.status(401).json({
      error: 'INVALID_CREDENTIALS',
      message: `Kredensial admin salah. Sisa percobaan: ${updatedRate.remainingAttempts}.`,
    });
  }

  AdminStore.recordLoginAttempt(ip, true);
  const userAgent = req.headers['user-agent'] as string | undefined;
  const token = AdminStore.createSession(username, ip, userAgent);

  res.json({
    success: true,
    token,
    admin: {
      username,
      role: 'SUPER_ADMIN',
    },
    message: 'Login berhasil. Selamat datang di Portal Admin /ZIN ZynderJhnzV1Beta.',
  });
});

// 2. Admin Auth Verify
app.get('/api/admin/auth/verify', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  res.json({
    valid: true,
    admin: {
      username: session.username,
      role: 'SUPER_ADMIN',
    },
  });
});

// 3. Admin Logout
app.post('/api/admin/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    AdminStore.destroySession(token, getClientIp(req));
  }
  res.json({ success: true, message: 'Berhasil keluar dari admin session.' });
});

// 4. Admin Change Password
app.post('/api/admin/auth/change-password', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const { oldPassword, newPassword } = req.body;

  if (!oldPassword || !newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'INVALID_INPUT', message: 'Password baru minimal 6 karakter.' });
  }

  const changed = AdminStore.changePassword(oldPassword, newPassword, session.username, getClientIp(req));
  if (!changed) {
    return res.status(400).json({ error: 'INVALID_OLD_PASSWORD', message: 'Kata sandi lama tidak cocok.' });
  }

  res.json({ success: true, message: 'Kata sandi admin berhasil diperbarui.' });
});

// 5. Admin Stats Overview
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const payments = AdminStore.getPayments();
  const subsList: SubscriptionRecord[] = [];
  subscriptionStore.forEach((sub) => subsList.push(sub));

  const totalUsers = Math.max(registeredUsers.size, subsList.length);
  const now = Date.now();
  const vipUsers = subsList.filter((s) => s.tier === 'VIP' && s.status === 'ACTIVE' && s.expiresAt > now).length;
  const vvipUsers = subsList.filter((s) => s.tier === 'VVIP' && s.status === 'ACTIVE' && s.expiresAt > now).length;
  const freeUsers = Math.max(0, totalUsers - vipUsers - vvipUsers);

  const pendingPaymentsCount = payments.filter((p) => p.status === 'PENDING').length;
  const approvedPayments = payments.filter((p) => p.status === 'APPROVED');
  const rejectedPaymentsCount = payments.filter((p) => p.status === 'REJECTED').length;
  const totalRevenueIdr = approvedPayments.reduce((acc, p) => acc + (p.amount || 0), 0);

  res.json({
    totalUsers,
    freeUsers,
    vipUsers,
    vvipUsers,
    pendingPaymentsCount,
    approvedPaymentsCount: approvedPayments.length,
    rejectedPaymentsCount,
    totalTransactionsCount: payments.length,
    totalRevenueIdr,
    activeSessionsCount: 1,
  });
});

// 6. Admin Payments List
app.get('/api/admin/payments', requireAdmin, (req, res) => {
  res.json({ payments: AdminStore.getPayments() });
});

// 7. Admin Approve Payment
app.post('/api/admin/payments/:id/approve', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const { id } = req.params;

  const result = AdminStore.approvePayment(id, session.username, getClientIp(req));
  if (!result.success) {
    return res.status(400).json(result);
  }

  // Activate VIP in subscriptionStore (Server Authoritative)
  const payment = result.payment!;
  const now = Date.now();
  const durationMs = (payment.durationDays || 30) * 86400000;

  const currentSub = subscriptionStore.get(payment.userId);
  const baseTime = currentSub && currentSub.expiresAt > now ? currentSub.expiresAt : now;
  const newExpiresAt = baseTime + durationMs;

  subscriptionStore.set(payment.userId, {
    uid: payment.userId,
    tier: payment.tier || 'VIP',
    status: 'ACTIVE',
    price: payment.amount,
    activatedAt: now,
    expiresAt: newExpiresAt,
  });

  res.json(result);
});

// 8. Admin Reject Payment
app.post('/api/admin/payments/:id/reject', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const { id } = req.params;
  const { reason } = req.body;

  const result = AdminStore.rejectPayment(id, reason, session.username, getClientIp(req));
  if (!result.success) {
    return res.status(400).json(result);
  }

  res.json(result);
});

// 9. Admin Users List
app.get('/api/admin/users', requireAdmin, (req, res) => {
  const now = Date.now();
  const userList: any[] = [];

  registeredUsers.forEach((user) => {
    const sub = subscriptionStore.get(user.uid);
    const isVipActive = sub && (sub.tier === 'VIP' || sub.tier === 'VVIP') && sub.status === 'ACTIVE' && sub.expiresAt > now;
    const isExpired = sub && sub.expiresAt <= now;
    const remainingDays = sub && sub.expiresAt > now ? Math.ceil((sub.expiresAt - now) / 86400000) : 0;

    userList.push({
      uid: user.uid,
      displayName: user.displayName,
      email: user.email,
      photoURL: user.photoURL,
      role: sub?.tier || 'FREE',
      status: isVipActive ? 'ACTIVE' : isExpired ? 'EXPIRED' : 'INACTIVE',
      createdAt: user.createdAt,
      vipExpiresAt: sub ? new Date(sub.expiresAt).toISOString() : undefined,
      vipActivatedAt: sub ? new Date(sub.activatedAt).toISOString() : undefined,
      remainingDays,
    });
  });

  res.json({ users: userList });
});

// 10. Admin Update User Role
app.post('/api/admin/users/:uid/role', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const { uid } = req.params;
  const { role, durationDays } = req.body;

  const now = Date.now();
  const days = Number(durationDays) || 30;
  const expiresAt = now + days * 86400000;

  if (role === 'FREE') {
    subscriptionStore.set(uid, {
      uid,
      tier: 'FREE',
      status: 'EXPIRED',
      price: 0,
      activatedAt: now,
      expiresAt: now,
    });
  } else {
    subscriptionStore.set(uid, {
      uid,
      tier: role === 'VVIP' ? 'VVIP' : 'VIP',
      status: 'ACTIVE',
      price: 10000,
      activatedAt: now,
      expiresAt,
    });
  }

  AdminStore.logAction(
    'UPDATE_USER_ROLE',
    session.username,
    `Role pengguna ${uid} diubah menjadi ${role} (${role === 'FREE' ? 'Dicabut' : `${days} hari`}).`,
    getClientIp(req),
    undefined,
    { uid, role, durationDays: days }
  );

  res.json({ success: true, message: `Role pengguna berhasil diubah ke ${role}.` });
});

// 11. Admin Extend VIP Days
app.post('/api/admin/users/:uid/extend', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const { uid } = req.params;
  const { days } = req.body;
  const extendDays = Number(days) || 30;
  const extendMs = extendDays * 86400000;
  const now = Date.now();

  const sub = subscriptionStore.get(uid);
  const baseTime = sub && sub.expiresAt > now ? sub.expiresAt : now;
  const newExpiresAt = baseTime + extendMs;

  subscriptionStore.set(uid, {
    uid,
    tier: sub?.tier && sub.tier !== 'FREE' ? sub.tier : 'VIP',
    status: 'ACTIVE',
    price: 10000,
    activatedAt: sub?.activatedAt || now,
    expiresAt: newExpiresAt,
  });

  AdminStore.logAction(
    'EXTEND_USER_VIP',
    session.username,
    `Masa aktif VIP pengguna ${uid} diperpanjang +${extendDays} hari (hingga ${new Date(newExpiresAt).toLocaleDateString('id-ID')}).`,
    getClientIp(req)
  );

  res.json({ success: true, message: `Masa aktif VIP diperpanjang +${extendDays} hari.` });
});

// 12. Admin Reset User WhatsApp Session
app.post('/api/admin/users/:uid/reset-wa', requireAdmin, async (req, res) => {
  const session = (req as any).adminSession;
  const { uid } = req.params;
  try {
    await WhatsAppManager.resetSession(uid);
    AdminStore.logAction('RESET_WA_SESSION', session.username, `Sesi WhatsApp pengguna ${uid} direset oleh admin.`, getClientIp(req));
    res.json({ success: true, message: 'Sesi WhatsApp pengguna berhasil direset.' });
  } catch (err: any) {
    res.status(500).json({ error: 'RESET_FAILED', message: err.message || 'Gagal mereset sesi WhatsApp.' });
  }
});

// 13. Admin Telegram Config
app.get('/api/admin/telegram/config', requireAdmin, (req, res) => {
  res.json(AdminStore.getTelegramConfig());
});

app.post('/api/admin/telegram/config', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const config = AdminStore.updateTelegramConfig(req.body, session.username, getClientIp(req));
  res.json({ success: true, config, message: 'Konfigurasi Telegram bot berhasil disimpan.' });
});

app.post('/api/admin/telegram/test', requireAdmin, async (req, res) => {
  const testMsg = `🚀 <b>ZYNDERJHNZV1BETA TELEGRAM BOT TEST</b>\n\n` +
    `Halo Admin! Koneksi notifikasi Telegram bot berhasil terhubung secara real-time ke sistem <code>/ZIN</code>.\n` +
    `Waktu server: <code>${new Date().toLocaleString('id-ID')}</code>\n\n` +
    `Notifikasi pembayaran baru akan dikirimkan ke sini secara otomatis beserta tombol Approve/Reject!`;

  const replyMarkup = {
    inline_keyboard: [
      [
        { text: '🌐 Buka Dashboard /ZIN', url: `http://${req.headers.host || 'localhost:3000'}/ZIN` }
      ]
    ]
  };

  const result = await AdminStore.sendTelegramMessage(testMsg, replyMarkup);
  if (!result.success) {
    return res.status(400).json({ error: 'TEST_FAILED', message: result.error || 'Gagal mengirim pesan uji coba.' });
  }
  res.json({ success: true, message: 'Pesan uji coba berhasil dikirim ke akun Telegram admin!' });
});

// 14. Telegram Bot Webhook / Inline Callback Query Handler
app.post('/api/admin/telegram/webhook', async (req, res) => {
  const update = req.body;
  if (!update) return res.json({ ok: true });

  const callbackQuery = update.callback_query;
  if (callbackQuery) {
    const fromId = String(callbackQuery.from?.id);
    const config = AdminStore.getTelegramConfig();

    // Verify sender matches authorized Admin Chat ID
    if (config.adminChatId && fromId !== String(config.adminChatId)) {
      if (config.botToken) {
        await fetch(`https://api.telegram.org/bot${config.botToken}/answerCallbackQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callback_query_id: callbackQuery.id,
            text: '❌ Akses Ditolak: Anda bukan Admin terdaftar!',
            show_alert: true,
          }),
        }).catch(() => {});
      }
      return res.json({ ok: false, error: 'Unauthorized Telegram user' });
    }

    const data = callbackQuery.data as string;
    if (data.startsWith('approve_')) {
      const paymentId = data.replace('approve_', '');
      const approveResult = AdminStore.approvePayment(paymentId, `TelegramAdmin (${fromId})`);

      if (approveResult.success && approveResult.payment) {
        const payment = approveResult.payment;
        const now = Date.now();
        const durationMs = (payment.durationDays || 30) * 86400000;
        subscriptionStore.set(payment.userId, {
          uid: payment.userId,
          tier: payment.tier || 'VIP',
          status: 'ACTIVE',
          price: payment.amount,
          activatedAt: now,
          expiresAt: now + durationMs,
        });
      }

      // Answer callback query & update Telegram message
      if (config.botToken) {
        await fetch(`https://api.telegram.org/bot${config.botToken}/answerCallbackQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callback_query_id: callbackQuery.id,
            text: approveResult.message,
          }),
        }).catch(() => {});

        if (callbackQuery.message) {
          await fetch(`https://api.telegram.org/bot${config.botToken}/editMessageText`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: callbackQuery.message.chat.id,
              message_id: callbackQuery.message.message_id,
              text: `${callbackQuery.message.text}\n\n✅ <b>DISETUJUI OLEH ADMIN VIA TELEGRAM (${fromId})</b>`,
              parse_mode: 'HTML',
            }),
          }).catch(() => {});
        }
      }
    } else if (data.startsWith('reject_')) {
      const paymentId = data.replace('reject_', '');
      const rejectResult = AdminStore.rejectPayment(paymentId, 'Ditolak langsung via tombol Telegram', `TelegramAdmin (${fromId})`);

      if (config.botToken) {
        await fetch(`https://api.telegram.org/bot${config.botToken}/answerCallbackQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            callback_query_id: callbackQuery.id,
            text: rejectResult.message,
          }),
        }).catch(() => {});

        if (callbackQuery.message) {
          await fetch(`https://api.telegram.org/bot${config.botToken}/editMessageText`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: callbackQuery.message.chat.id,
              message_id: callbackQuery.message.message_id,
              text: `${callbackQuery.message.text}\n\n❌ <b>DITOLAK OLEH ADMIN VIA TELEGRAM (${fromId})</b>`,
              parse_mode: 'HTML',
            }),
          }).catch(() => {});
        }
      }
    }
  }

  res.json({ ok: true });
});

// 15. Admin System & QRIS Settings
app.get('/api/admin/settings', requireAdmin, (req, res) => {
  res.json(AdminStore.getSettings());
});

app.post('/api/admin/settings', requireAdmin, (req, res) => {
  const session = (req as any).adminSession;
  const settings = AdminStore.updateSettings(req.body, session.username, getClientIp(req));
  res.json({ success: true, settings, message: 'Pengaturan website dan QRIS berhasil diperbarui.' });
});

// 16. Admin Audit Logs
app.get('/api/admin/logs', requireAdmin, (req, res) => {
  res.json({ logs: AdminStore.getAuditLogs(300) });
});

// --- PUBLIC & USER CLIENT ENDPOINTS ---

// Public dynamic website settings (consumed live by user dashboard & payment modals)
app.get('/api/public/settings', (req, res) => {
  const s = AdminStore.getSettings();
  res.json({
    siteName: s.siteName,
    siteDescription: s.siteDescription,
    qrisImageUrl: s.qrisImageUrl,
    qrisManualActive: s.qrisManualActive,
    qiospayActive: s.qiospayActive,
    vipPrice: s.vipPrice,
    vipDurationDays: s.vipDurationDays,
    whatsappChannelUrl: s.whatsappChannelUrl,
    whatsappGroupUrl: s.whatsappGroupUrl,
    adminWhatsappUrl: s.adminWhatsappUrl,
    adminTelegramUrl: s.adminTelegramUrl,
    customerServiceUrl: s.customerServiceUrl,
    announcementActive: s.announcementActive,
    announcementText: s.announcementText,
    announcementType: s.announcementType,
    maintenanceMode: s.maintenanceMode,
    maintenanceMessage: s.maintenanceMessage,
  });
});

// User manual payment submission with receipt proof upload
app.post('/api/membership/submit-manual-payment', requireAuth, (req: AuthRequest, res) => {
  const uid = req.userUid!;
  const email = req.userEmail || 'user@zynder.com';
  const { paymentId, senderName, senderAccount, notes, receiptUrl, tier, amount, durationDays, method } = req.body;

  const id = paymentId || `INV-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`;
  const settings = AdminStore.getSettings();

  const payment = AdminStore.createPayment({
    id,
    userId: uid,
    userName: senderName || email.split('@')[0],
    userEmail: email,
    tier: tier === 'VVIP' ? 'VVIP' : 'VIP',
    amount: amount || settings.vipPrice || 10000,
    currency: 'IDR',
    durationDays: durationDays || settings.vipDurationDays || 30,
    method: method || 'QRIS_MANUAL',
    receiptUrl: receiptUrl || '',
    senderName,
    senderAccount,
    notes,
  });

  res.json({
    success: true,
    message: 'Bukti transfer pembayaran berhasil dikirimkan. Menunggu persetujuan administrator.',
    payment,
  });
});

// Mount Vite or serve static
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ZynderJhnzV1Beta Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
